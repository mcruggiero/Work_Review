# ========================================================================
# SCORECARD MODELING MODULE
# Contains: ScoreCardModeling for ML model training and prediction
# ========================================================================

import os
import gc
import ast
from typing import Any, Optional

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

from .config import ScoreCardConfig, ScoreCardState, Horizon, SUPPORTED_HORIZONS
from .connections import ConnectionManager


class ScoreCardModeling:
    """
    Handles model training, evaluation, and prediction for ScoreCard.

    Supports multi-horizon prediction (H1, H2) with separate models
    trained for each horizon.
    """

    def __init__(
        self,
        config: ScoreCardConfig,
        state: ScoreCardState,
        conn: ConnectionManager
    ) -> None:
        self.config = config
        self.state = state
        self.conn = conn
        self.max_workers = os.cpu_count() // 4 or 1

    def build_model_grid(self) -> None:
        """
        Generates the model configuration grid from the Cartesian product
        of feature, sampling, and vectorizer options.
        """
        grid = []
        for feat_name, feat_cfg in self.state.feature_matrix.items():
            has_text = bool(feat_cfg.get("text_fields"))
            for sample_name in self.state.sampling_matrix:
                for vec_name, vec_cfg in self.state.vectorization_matrix.items():
                    if not has_text and vec_cfg["text_vectorizer"] != "count":
                        continue
                    grid.append({
                        "feature_set": feat_name,
                        "sampling_strategy": sample_name,
                        "vectorizer_strategy": vec_name
                    })
        self.state.model_grid_df = pd.DataFrame(grid)

    def prepare_dataset(
        self,
        sid_df: pd.DataFrame,
        config_row: dict[str, Any],
        horizon: Horizon = Horizon.H1
    ) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
        """
        Constructs a training dataset (X, y) from a specific model configuration and horizon.

        Args:
            sid_df: Input dataframe with enriched scorecard notes.
            config_row: A row from the model grid containing feature_set, sampling_strategy, vectorizer_strategy.
            horizon: The prediction horizon (H1 or H2).

        Returns:
            X: Final feature matrix.
            y: Target label array.
            metadata: Fitted transformers and config references.
        """
        feature_key = config_row["feature_set"]
        sampling_key = config_row["sampling_strategy"]
        vectorizer_key = config_row["vectorizer_strategy"]

        features = self.state.feature_matrix[feature_key]
        sampling = self.state.sampling_matrix[sampling_key]
        vectorization = self.state.vectorization_matrix[vectorizer_key]

        text_fields = features.get("text_fields", [])
        numeric_fields = features.get("numeric_fields", [])
        categorical_fields = features.get("categorical_fields", [])

        # Determine column names based on horizon
        if horizon == Horizon.H1:
            trainable_col = "trainable"
            target_col = "target"
        else:
            trainable_col = f"trainable_h{int(horizon)}"
            target_col = f"target_h{int(horizon)}"

        # Track total before filtering
        total_notes = len(sid_df)

        # Filter to trainable rows for this horizon
        # NOTE: We filter on three conditions:
        #   1. SID must have enough notes to meet training_length requirement
        #   2. Row must be marked trainable for this specific horizon
        #   3. Target must be a valid label (0=Green, 1=Yellow, 2=Red)
        sid_df = sid_df[
            (sid_df["total_notes"] >= self.config.training_length) &
            (sid_df[trainable_col].astype(bool)) &
            (sid_df[target_col].isin([0, 1, 2]))
        ].copy()

        # Calculate % culled
        kept_notes = len(sid_df)
        if total_notes > 0:
            percent_culled = 100 * (total_notes - kept_notes) / total_notes
        else:
            percent_culled = 0.0

        self.conn.report("DATA", (
            f"[H{int(horizon)}] Filtered to {kept_notes} trainable rows with total_notes >= {self.config.training_length} "
            f"and valid target (0/1/2) {percent_culled:.1f}% culled"
        ))

        # Handle class imbalance via downsampling if configured
        # NOTE: "all_green" == 1 means the SID had 4 consecutive green notes (majority class).
        # We downsample this majority to balance against non-green sequences.
        # The majority_multiplier controls how much larger majority can be vs minority.
        # Example: multiplier=2 means keep at most 2x as many majority samples as minority.
        if sampling["method"] == "downsample":
            majority = sid_df[sid_df["all_green"] == 1].sample(frac=1, random_state=42)
            minority = sid_df[sid_df["all_green"] == 0]
            keep = min(len(minority) * sampling["majority_multiplier"], len(majority))
            df = pd.concat([majority.iloc[:keep], minority]).sample(frac=1, random_state=42)
        else:
            df = sid_df.copy()

        # Use horizon-specific target column
        y = df[target_col].values

        parts = []
        metadata = {
            "horizon": int(horizon),
            "feature_set": feature_key,
            "sampling": sampling_key,
            "vectorizer": vectorizer_key,
            "text_vectorizer": None,
            "numeric_scaler": None,
            "cat_encoder": None,
            "text_fields": text_fields,
            "numeric_fields": numeric_fields,
            "categorical_fields": categorical_fields
        }

        if text_fields:
            vectorizer_type = vectorization["text_vectorizer"]
            vec_cls = CountVectorizer if vectorizer_type == "count" else TfidfVectorizer

            # NOTE: Vectorizer params come from state.vectorizer_params (loaded from model_matrix.json)
            # not from the vectorization_matrix entry. This allows global vectorizer settings
            # (like ngram_range, max_features) to be shared across all vectorizer strategies.
            vec_params = self.state.vectorizer_params or {}
            vectorizer = vec_cls(**vec_params)

            # Use the first text field as the corpus (typically 'complete_main_words')
            corpus = df[text_fields[0]].fillna("").astype(str).tolist()
            X_text = vectorizer.fit_transform(corpus).toarray()
            parts.append(X_text)
            metadata["text_vectorizer"] = vectorizer

        if numeric_fields:
            scaler = StandardScaler()
            X_numeric = scaler.fit_transform(df[numeric_fields].fillna(0))
            parts.append(X_numeric)
            metadata["numeric_scaler"] = scaler

        if categorical_fields:
            if vectorization.get("cat_encoder") == "label":
                encoded_cols = []
                encoders = {}
                for col in categorical_fields:
                    le = LabelEncoder()
                    encoded = le.fit_transform(df[col].astype(str))
                    encoded_cols.append(encoded.reshape(-1, 1))
                    encoders[col] = le
                X_cat = np.hstack(encoded_cols)
                metadata["cat_encoder"] = encoders
            else:
                ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
                X_cat = ohe.fit_transform(df[categorical_fields].astype(str))
                metadata["cat_encoder"] = ohe
            parts.append(X_cat)

        X = np.hstack(parts) if parts else np.empty((len(df), 0))
        return X, y, metadata

    def prepare_prediction_matrix(
        self,
        sid_df: pd.DataFrame,
        metadata: dict[str, Any]
    ) -> np.ndarray:
        """
        Generates a feature matrix (X) for prediction using a pre-fit model's metadata.
        """
        parts = []

        if metadata["text_vectorizer"] and metadata["text_fields"]:
            vec = metadata["text_vectorizer"]
            corpus = sid_df[metadata["text_fields"][0]].fillna("").astype(str).tolist()
            parts.append(vec.transform(corpus).toarray())

        if metadata["numeric_scaler"] and metadata["numeric_fields"]:
            scaler = metadata["numeric_scaler"]
            X_numeric = scaler.transform(sid_df[metadata["numeric_fields"]].fillna(0))
            parts.append(X_numeric)

        if metadata["cat_encoder"] and metadata["categorical_fields"]:
            encoder = metadata["cat_encoder"]
            if isinstance(encoder, dict):
                encoded_cols = []
                for col, le in encoder.items():
                    encoded = le.transform(sid_df[col].astype(str))
                    encoded_cols.append(encoded.reshape(-1, 1))
                X_cat = np.hstack(encoded_cols)
            else:
                X_cat = encoder.transform(sid_df[metadata["categorical_fields"]].astype(str))
            parts.append(X_cat)

        return np.hstack(parts) if parts else np.empty((len(sid_df), 0))

    def find_best_model(self, horizon: Horizon = Horizon.H1) -> None:
        """
        Trains and evaluates logistic regression models for a specific horizon.

        Selects the best model based on minimizing false negatives,
        with accuracy as a tiebreaker.
        """
        results = {}
        h_int = int(horizon)

        # Guard: Ensure model_weights is defined in model_matrix.json
        if not self.state.model_weights:
            raise ValueError(
                "model_weights not defined in config. "
                "Add 'model_weights' list to model_matrix.json with class weight dicts like {0: 0.5, 1: 1.35, 2: 1.15}"
            )

        # Normalize weights to ensure keys are integers
        # NOTE: JSON serialization converts int keys to strings, so we need to convert back.
        # Example: {"0": 0.5, "1": 1.35, "2": 1.15} -> {0: 0.5, 1: 1.35, 2: 1.15}
        int_weights = [{int(k): v for k, v in weight.items()} for weight in self.state.model_weights]

        # Generate all combinations of (config_row, weight)
        # This creates the full grid: features × sampling × vectorizers × class_weights
        tasks = [
            (row, weight)
            for _, row in self.state.model_grid_df.iterrows()
            for weight in int_weights
        ]

        self.conn.report("MODL", f"[H{h_int}] Training {len(tasks)} models serially with LogisticRegression(n_jobs=-1)")

        # Serial model training
        import time
        train_start = time.time()
        for task_idx, (row, weight) in enumerate(tasks):
            # Progress indicator every 5 models
            if task_idx > 0 and task_idx % 5 == 0:
                elapsed = time.time() - train_start
                rate = task_idx / elapsed if elapsed > 0 else 0
                remaining = (len(tasks) - task_idx) / rate if rate > 0 else 0
                self.conn.report("MODL", f"[H{h_int}] Progress: {task_idx}/{len(tasks)} models ({elapsed:.0f}s elapsed, ~{remaining:.0f}s remaining)")

            try:
                dataset_key = f"H{h_int} | {row['feature_set']} | {row['sampling_strategy']} | {row['vectorizer_strategy']}"

                X, y, meta = self.prepare_dataset(self.state.sid_df, row, horizon=horizon)
                dataset = {"X": X, "y": y, "metadata": meta}

                model_id, result = self.train_one_model(dataset_key, dataset, weight, horizon=horizon, n_jobs=-1)
                results[model_id] = result

                if result.get("model"):
                    self.conn.report("MODL", f"[H{h_int}] Completed: {model_id} | FN={result['total_false_negatives']} | Acc={result['accuracy']:.4f}")
                else:
                    self.conn.report("MODL", f"[H{h_int}] Error in: {model_id} | {result.get('error')}")

            except Exception as e:
                model_id = f"H{h_int} | {row['feature_set']} | {row['sampling_strategy']} | {row['vectorizer_strategy']} | {weight}"
                self.conn.report("MODL", f"[H{h_int}] Training failed for model: {model_id}. Error: {str(e)}")
                results[model_id] = {
                    "model": None,
                    "error": str(e),
                    "total_false_negatives": None,
                    "horizon": h_int
                }

        # Store results in horizon-specific bucket
        self.state.models_by_horizon[h_int] = results

        # For H1 backward compatibility
        if horizon == Horizon.H1:
            self.state.models = results

        # Filter valid models
        valid_models = {
            k: v for k, v in results.items()
            if v.get("model") and v.get("total_false_negatives") is not None
        }

        # Select best model for this horizon
        if valid_models:
            best_key = min(
                valid_models,
                key=lambda k: (
                    valid_models[k]["total_false_negatives"],
                    -valid_models[k]["accuracy"]
                )
            )
            self.state.best_model_by_horizon[h_int] = valid_models[best_key]
            self.state.best_model_key_by_horizon[h_int] = best_key

            # For H1 backward compatibility
            if horizon == Horizon.H1:
                self.state.best_model = valid_models[best_key]
                self.state.best_model_key = best_key

            self.conn.report("MODL", f"[H{h_int}] Selected best model: {best_key} | FN={valid_models[best_key]['total_false_negatives']}")
        else:
            self.state.best_model_by_horizon[h_int] = None
            self.state.best_model_key_by_horizon[h_int] = None

            if horizon == Horizon.H1:
                self.state.best_model = None
                self.state.best_model_key = None

        if not self.state.best_model_key_by_horizon.get(h_int):
            raise ValueError(f"Error! No model found for horizon H{h_int}")

    def train_one_model(
        self,
        dataset_key: str,
        dataset: dict[str, Any],
        class_weights: dict[int, float],
        horizon: Horizon = Horizon.H1,
        n_jobs: int = -1
    ) -> tuple[str, dict[str, Any]]:
        """
        Trains a logistic regression model on a single dataset/config.
        """
        X = dataset["X"]
        y = dataset["y"]
        meta = dataset["metadata"]
        h_int = int(horizon)

        class_weights = {int(k): v for k, v in class_weights.items()}
        model_id = f"{dataset_key} | Weights {class_weights}"

        classes = np.unique(y)
        if len(classes) < 2:
            raise ValueError(f"Only one class present in target: {classes}")

        if not set(classes).issubset(class_weights.keys()):
            raise ValueError(
                f"Target classes {list(classes)} not all found in class_weights keys {list(class_weights.keys())}"
            )

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )

        model = LogisticRegression(
            random_state=42,
            solver="newton-cg",
            n_jobs=n_jobs,
            max_iter=2000,
            multi_class='multinomial',
            class_weight=class_weights
        )
        model.fit(X_train, y_train)

        y_pred = model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        report = classification_report(y_test, y_pred, digits=4)
        cm = confusion_matrix(y_test, y_pred, labels=model.classes_)

        false_negatives = {
            "2 → 0": int(cm[2, 0]) if cm.shape[0] > 2 else 0,
            "2 → 1": int(cm[2, 1]) if cm.shape[0] > 2 else 0,
            "1 → 0": int(cm[1, 0]) if cm.shape[0] > 1 else 0
        }
        total_fn = sum(false_negatives.values())

        top_idx = np.argsort(np.abs(model.coef_).sum(axis=0))[::-1][:5]

        result = {
            "model": model,
            "horizon": h_int,
            "accuracy": acc,
            "classification_report": report,
            "confusion_matrix": cm,
            "top_coef_indices": top_idx,
            "class_weights": class_weights,
            "false_negatives": false_negatives,
            "total_false_negatives": total_fn,
            "feature_set": meta["feature_set"],
            "sampling": meta["sampling"],
            "vectorizer": meta["vectorizer"],
            "vectorizer_obj": meta.get("text_vectorizer"),
            "vectorizer_params": meta.get("vectorizer_params", {}),
            "metadata": meta
        }

        del X_train, X_test, y_train, y_test, y_pred
        gc.collect()

        return model_id, result

    def _log_model_results(self, result: dict, h_int: int) -> None:
        """
        Logs detailed model results including confusion matrix and metrics.
        """
        self.conn.report("MODL", f"[H{h_int}] " + "-" * 50)
        self.conn.report("MODL", f"[H{h_int}] MODEL EVALUATION RESULTS")
        self.conn.report("MODL", f"[H{h_int}] " + "-" * 50)

        # Accuracy
        acc = result.get("accuracy", 0)
        self.conn.report("MODL", f"[H{h_int}] Accuracy: {acc:.4f} ({acc*100:.2f}%)")

        # False negatives breakdown
        fn = result.get("false_negatives", {})
        total_fn = result.get("total_false_negatives", 0)
        self.conn.report("MODL", f"[H{h_int}] False Negatives: {total_fn} total")
        for k, v in fn.items():
            self.conn.report("MODL", f"[H{h_int}]   {k}: {v}")

        # Confusion Matrix
        cm = result.get("confusion_matrix")
        if cm is not None:
            self.conn.report("MODL", f"[H{h_int}] Confusion Matrix (rows=actual, cols=predicted):")
            self.conn.report("MODL", f"[H{h_int}]              Green  Yellow    Red")
            labels = ["Green ", "Yellow", "Red   "]
            for i, row in enumerate(cm):
                row_str = "  ".join(f"{val:6d}" for val in row)
                if i < len(labels):
                    self.conn.report("MODL", f"[H{h_int}]   {labels[i]}  {row_str}")

        # Class weights used
        weights = result.get("class_weights", {})
        self.conn.report("MODL", f"[H{h_int}] Class Weights: {weights}")
        self.conn.report("MODL", f"[H{h_int}] " + "-" * 50)

    def predict_with_best_model(
        self,
        sid_df: pd.DataFrame,
        horizon: Horizon = Horizon.H1
    ) -> pd.DataFrame:
        """
        Applies the best trained model for a specific horizon to generate predictions.

        Returns a copy of sid_df with appended prediction columns.
        """
        h_int = int(horizon)

        # Get best model for this horizon
        best = self.state.best_model_by_horizon.get(h_int)

        # Fallback to legacy location for H1
        if best is None and horizon == Horizon.H1:
            best = self.state.best_model

        if not best or not best.get("model"):
            raise ValueError(f"No trained model available for horizon H{h_int}.")

        model = best["model"]
        metadata = best["metadata"]
        X = self.prepare_prediction_matrix(sid_df, metadata)

        y_pred = model.predict(X)
        y_proba = model.predict_proba(X)

        df = sid_df.copy()

        # Column naming based on horizon
        if horizon == Horizon.H1:
            df["predicted_label"] = y_pred
            df["prob_green"] = y_proba[:, 0] if y_proba.shape[1] > 0 else np.nan
            df["prob_yellow"] = y_proba[:, 1] if y_proba.shape[1] > 1 else np.nan
            df["prob_red"] = y_proba[:, 2] if y_proba.shape[1] > 2 else np.nan
            df["horizon"] = h_int
        else:
            suffix = f"_h{h_int}"
            df[f"predicted_label{suffix}"] = y_pred
            df[f"prob_green{suffix}"] = y_proba[:, 0] if y_proba.shape[1] > 0 else np.nan
            df[f"prob_yellow{suffix}"] = y_proba[:, 1] if y_proba.shape[1] > 1 else np.nan
            df[f"prob_red{suffix}"] = y_proba[:, 2] if y_proba.shape[1] > 2 else np.nan
            df[f"horizon{suffix}"] = h_int

        # Store in horizon-specific location
        self.state.predictions_df_by_horizon[h_int] = df

        # For H1 backward compatibility
        if horizon == Horizon.H1:
            self.state.predictions_df = df

        return df

    def load_best_model_by_key(
        self,
        model_key: str,
        horizon: Horizon = Horizon.H1,
        generate_predictions: bool = True
    ) -> Optional[pd.DataFrame]:
        """
        Reconstructs and re-trains a model from a stored model_key string.
        Sets it as best model for the specified horizon.
        """
        parts = model_key.strip().split(" | ")

        # Parse key format - detect if horizon prefix is present
        if parts[0].startswith("H") and parts[0][1:].isdigit():
            # New format with horizon prefix
            h_int = int(parts[0][1:])
            horizon = Horizon(h_int)
            feature_set = parts[1]
            sampling_strategy = parts[2]
            vectorizer_strategy = parts[3]
            class_weights_str = parts[4]
            if len(parts) != 5:
                raise ValueError(f"Model key has wrong format: {model_key}")
        else:
            # Legacy format without horizon prefix (assume H1)
            if len(parts) != 4:
                raise ValueError(f"Model key has wrong format: {model_key}")
            h_int = int(horizon)
            feature_set = parts[0]
            sampling_strategy = parts[1]
            vectorizer_strategy = parts[2]
            class_weights_str = parts[3]

        class_weights = ast.literal_eval(class_weights_str)
        config_row = {
            "feature_set": feature_set,
            "sampling_strategy": sampling_strategy,
            "vectorizer_strategy": vectorizer_strategy
        }

        X, y, meta = self.prepare_dataset(self.state.sid_df, config_row, horizon=horizon)
        dataset = {"X": X, "y": y, "metadata": meta}

        dataset_key = f"H{h_int} | {feature_set} | {sampling_strategy} | {vectorizer_strategy}"
        model_id, result = self.train_one_model(
            dataset_key=dataset_key,
            dataset=dataset,
            class_weights=class_weights,
            horizon=horizon,
            n_jobs=-1
        )

        # Set as best model for this horizon
        self.state.best_model_by_horizon[h_int] = result
        self.state.best_model_key_by_horizon[h_int] = model_id

        # For H1 backward compatibility
        if horizon == Horizon.H1:
            self.state.best_model = result
            self.state.best_model_key = model_id

        if result.get("model") is None:
            raise ValueError(f"Model training failed. Reason: {result.get('error')}")

        self.conn.report("MODL", f"[H{h_int}] Rehydrated best model: {model_id}")

        # Log confusion matrix and metrics
        self._log_model_results(result, h_int)

        # Optional predictions
        if generate_predictions:
            df_with_preds = self.predict_with_best_model(self.state.sid_df, horizon=horizon)
            return df_with_preds

        return None

    def merge_data(self) -> None:
        """
        Merges prediction columns from all horizons into enriched_df on sid_key → last_sid,
        producing complete_df for downstream tasks.

        JOIN LOGIC EXPLAINED:
        ---------------------
        enriched_df contains one row per scorecard note (identified by sid_key).
        predictions_df contains one row per sliding window (identified by last_sid).

        The join key is: enriched_df.sid_key == predictions_df.last_sid

        This means: "For each note in enriched_df, find the prediction window
        where that note was the LAST INPUT note (i.e., the most recent note
        the model saw when making its prediction)."

        Example:
            Window [note1, note2, note3, note4] -> predicts note5
            last_sid = note4's sid_key
            When we join, note4 in enriched_df gets the prediction for note5.

        This is correct because we want to attach "what did the model predict
        would come AFTER this note?" to each note in the dataset.
        """
        enriched_df = self.state.enriched_df.copy()

        # Start with H1 predictions (fall back to legacy location if needed)
        # NOTE: Can't use `or` with DataFrames - must check explicitly for None
        h1_df = self.state.predictions_df_by_horizon.get(1)
        if h1_df is None:
            h1_df = self.state.predictions_df

        if h1_df is None:
            self.conn.report("JOIN", "No H1 predictions available for merge")
            return

        # Base columns to merge (window metadata + input note references)
        base_cols = [
            "last_sid",      # Join key - the last input note in the window
            "sid_key_0",     # First input note
            "sid_key_1",     # Second input note
            "sid_key_2",     # Third input note
            "sid_key_3",     # Fourth input note (same as last_sid)
            "all_green",     # Whether all 4 input notes were green
            "color_set",     # Color sequence string like "GGYG"
            "trainable",     # Whether this window had a valid target for training
        ]

        # H1 prediction columns (model outputs)
        h1_pred_cols = [
            "predicted_label",   # 0=Green, 1=Yellow, 2=Red
            "prob_green",        # P(next note is Green)
            "prob_yellow",       # P(next note is Yellow)
            "prob_red",          # P(next note is Red)
        ]

        # Select only columns that exist (defensive coding)
        h1_merge_cols = base_cols + h1_pred_cols
        h1_merge_cols = [c for c in h1_merge_cols if c in h1_df.columns]
        h1_subset = h1_df[h1_merge_cols].copy()

        # Merge H1 predictions onto enriched notes
        complete_df = enriched_df.merge(
            h1_subset,
            how="left",
            left_on="sid_key",
            right_on="last_sid"
        )

        # Add human-readable color label for H1
        complete_df["predicted_color"] = complete_df["predicted_label"].map({
            0: "Green",
            1: "Yellow",
            2: "Red"
        })

        # Merge H2 predictions if available
        h2_df = self.state.predictions_df_by_horizon.get(2)
        if h2_df is not None:
            h2_pred_cols = [
                "predicted_label_h2",
                "prob_green_h2",
                "prob_yellow_h2",
                "prob_red_h2",
                "trainable_h2",
            ]
            h2_merge_cols = ["last_sid"] + [c for c in h2_pred_cols if c in h2_df.columns]
            h2_subset = h2_df[h2_merge_cols].copy()

            # Merge H2
            complete_df = complete_df.merge(
                h2_subset,
                how="left",
                left_on="sid_key",
                right_on="last_sid",
                suffixes=("", "_dup")
            )

            # Drop duplicate last_sid column
            if "last_sid_dup" in complete_df.columns:
                complete_df.drop(columns=["last_sid_dup"], inplace=True)

            # Add human-readable color label for H2
            complete_df["predicted_color_h2"] = complete_df["predicted_label_h2"].map({
                0: "Green",
                1: "Yellow",
                2: "Red"
            })

            self.conn.report("JOIN", f"Merged H1 and H2 predictions. Final shape: {complete_df.shape}")
        else:
            self.conn.report("JOIN", f"Merged H1 predictions only. Final shape: {complete_df.shape}")

        # Store result
        self.state.complete_df = complete_df
