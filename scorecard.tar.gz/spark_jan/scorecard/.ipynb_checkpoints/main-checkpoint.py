#!/usr/bin/env python3
# ========================================================================
# SCORECARD MAIN ENTRY POINT
# Run the full ScoreCard ML pipeline
# ========================================================================

import warnings

# Suppress common warnings
from bs4 import MarkupResemblesLocatorWarning
warnings.filterwarnings("ignore", category=MarkupResemblesLocatorWarning)
warnings.filterwarnings("ignore", category=FutureWarning, message="DataFrame.applymap has been deprecated.*")
warnings.filterwarnings("ignore", message="pandas only supports SQLAlchemy")
warnings.filterwarnings("ignore", category=DeprecationWarning, message=".*toDlpack.*")

from .config import ScoreCardConfig, ScoreCardState
from .connections import ConnectionManager
from .modeling import ScoreCardModeling
from .pipeline import ScoreCardPipeline
from .rag import ScoreCardRag


def run_pipeline(
    sql_download: bool = True,
    enable_nlp: bool = True,
    build_models: bool = True,
    run_predictions: bool = True,
    build_rag: bool = True,
) -> tuple[ScoreCardState, ScoreCardPipeline, ScoreCardRag]:
    """
    Initialize and run the ScoreCard pipeline.

    Args:
        sql_download: Whether to download fresh data from SQL (vs load from ES)
        enable_nlp: Whether to run NLP enrichment
        build_models: Whether to train models
        run_predictions: Whether to run predictions
        build_rag: Whether to build RAG embeddings

    Returns:
        Tuple of (state, pipeline, rag) for further inspection/use
    """
    # Initialize configuration
    config = ScoreCardConfig(
        sql_download=sql_download,
        enable_nlp=enable_nlp,
        build_models=build_models,
        run_predictions=run_predictions,
        build_rag=build_rag,
    )

    # Initialize state (loads model matrices, spacy, prompts)
    state = ScoreCardState(config=config)

    # Initialize connections (SQL, ES, GPT, embeddings)
    conn = ConnectionManager(config=config, state=state)

    # Initialize modeler
    modeler = ScoreCardModeling(config=config, state=state, conn=conn)

    # Initialize and run pipeline
    pipeline = ScoreCardPipeline(
        config=config,
        state=state,
        conn=conn,
        modeler=modeler
    )
    pipeline.run()

    # Initialize RAG (optional)
    rag = ScoreCardRag(config=config, state=state, conn=conn)

    if build_rag:
        rag.embed_and_index_notes()

    return state, pipeline, rag


def main():
    """Main entry point for command-line execution."""
    print("=" * 60)
    print("SCORECARD ML PIPELINE")
    print("=" * 60)

    state, pipeline, rag = run_pipeline(
        sql_download=True,
        enable_nlp=True,
        build_models=True,
        run_predictions=True,
        build_rag=True,
    )

    print("=" * 60)
    print("PIPELINE COMPLETE")
    print("=" * 60)

    # Print summary
    if state.complete_df is not None:
        print(f"Final dataset shape: {state.complete_df.shape}")

    if state.best_model_key_by_horizon:
        print("\nBest models by horizon:")
        for h, key in state.best_model_key_by_horizon.items():
            print(f"  H{h}: {key}")

    return state, pipeline, rag


if __name__ == "__main__":
    main()
