# ========================================================================
# SCORECARD TEXT PREP MODULE
# Contains: ScoreCardTextPrep for NLP enrichment and window generation
# ========================================================================

import re
from typing import Any
from collections import defaultdict

import pandas as pd
from bs4 import BeautifulSoup

from .config import ScoreCardState, Horizon, horizon_offset


class ScoreCardTextPrep:
    """
    Handles all text-based preparation steps for ScoreCard modeling.

    Responsibilities:
    - HTML cleaning and SID key generation
    - SpaCy-based NLP enrichment (verbs, adjectives, noun chunks)
    - Main word extraction and lowercase normalization
    - Target label creation and next color mapping
    - SID-based sliding history window construction for model training
    """

    def __new__(cls, *args, **kwargs):
        raise TypeError("ScoreCardTextPrep is a static utility class and cannot be instantiated.")

    @staticmethod
    def enrich(state: ScoreCardState) -> None:
        """
        Performs HTML-to-text cleaning, extracts linguistic features using SpaCy,
        generates main_words, and maps label fields on the `details_df`.
        Results are stored in `state.enriched_df`.
        """
        df = state.details_df.copy()

        df["sid_key"] = (
            df["SID"].astype(str).str.zfill(6) + "." +
            df["Note_Year"].astype(str) + "." +
            df["Note_Month"].astype(str) + "." +
            df["Scorecard_Detail_Note_SID"].astype(str).str.zfill(6)
        )

        df = df.sort_values(by="sid_key", ascending=True).reset_index(drop=True)
        df["pre_scrub_text"] = df["Scorecard_Note"].apply(ScoreCardTextPrep._html_to_text)
        df["Scorecard_Note"] = df["pre_scrub_text"].copy()

        docs = list(state.nlp.pipe(df["pre_scrub_text"].tolist(), disable=["ner"]))
        df["verbs"] = [" ".join(t.lemma_ for t in doc if t.pos_ == "VERB") for doc in docs]
        df["adjectives"] = [" ".join(t.lemma_ for t in doc if t.pos_ == "ADJ") for doc in docs]
        df["noun_chunks"] = [" ".join(chunk.text for chunk in doc.noun_chunks) for doc in docs]

        df["main_words"] = (
            df["verbs"] + " " + df["adjectives"] + " " + df["noun_chunks"]
        ).str.lower().replace(r"\s+", " ", regex=True)

        label_map = defaultdict(lambda: -1, {"G": 0, "Y": 1, "R": 2})
        df = df.dropna(subset=["Overall"])
        df["target"] = df["Overall"].map(label_map)

        df["next_color_code"] = (
            df.groupby("SID")["Overall"]
              .shift(-1)
              .map(label_map)
              .fillna(-1)
              .astype(int)
        )

        grouped = df.groupby("SID", group_keys=False, sort=False)
        df["note_history"] = grouped["Scorecard_Detail_Note_SID"].apply(
            lambda col: pd.Series(
                [""] + [";".join(col.astype(str).iloc[:i]) for i in range(1, len(col))],
                index=col.index
            )
        )

        state.enriched_df = df

    @staticmethod
    def _html_to_text(html: str) -> str:
        """Convert HTML content to clean text."""
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup.find_all(['p', 'li']):
            text = tag.get_text(strip=True)
            if text and not re.search(r'[.!?]\s*$', text) and len(text.split()) > 2:
                tag.append('.')
        for br in soup.find_all('br'):
            br.replace_with(' ')
        text = soup.get_text(separator=' ')
        text = re.sub(r'\s*\.\s*', '. ', text)
        text = re.sub(r'\.\s*\.+', '. ', text)
        text = re.sub(r'([:;])\s*\.', r'\1', text)
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'<.*?>', '', text)
        text = re.sub(r'&(?:[a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});', '', text)
        text = re.sub(r'[\n\r\t]+', ' ', text)
        return text.strip()

    # ========================================================================
    # WINDOW GENERATION - PHASE 1: Pure Chronological Slicing
    # ========================================================================
    @staticmethod
    def _generate_raw_windows(
        notes: list[pd.Series],
        max_input_notes: int = 4
    ) -> list[dict]:
        """
        Phase 1 of window generation: Pure chronological slicing.

        Returns raw windows without any trainability determination.
        Each window contains exactly `max_input_notes` input notes when possible.

        VISUAL EXAMPLE (8 notes, max_input_notes=4):
        ---------------------------------------------
        Notes:     [1] [2] [3] [4] [5] [6] [7] [8]
        Index:      0   1   2   3   4   5   6   7

        Window 0:  [1] [2] [3] [4]              last_input_idx=3
        Window 1:      [2] [3] [4] [5]          last_input_idx=4
        Window 2:          [3] [4] [5] [6]      last_input_idx=5
        Window 3:              [4] [5] [6] [7]  last_input_idx=6
        Window 4:                  [5] [6] [7] [8]  last_input_idx=7

        Note: This phase does NOT determine targets or trainability.
        That's handled in Phase 2 (_interpret_window_for_horizon).

        Args:
            notes: Chronologically ordered list of notes for a single SID
            max_input_notes: Number of input notes per window (default 4)

        Returns:
            List of raw window dicts, each containing:
                - input_notes: List of input note Series
                - last_input_idx: Index of the last input note in the original notes list
                - window_index: Sequential index of this window
        """
        results = []
        n = len(notes)

        # Need at least max_input_notes to form a valid window
        if n < max_input_notes:
            return results

        # Generate windows where last input note is at index i
        # Starting at index (max_input_notes - 1) ensures we have enough prior notes
        for window_idx, i in enumerate(range(max_input_notes - 1, n)):
            input_notes = notes[i - max_input_notes + 1: i + 1]
            results.append({
                "input_notes": input_notes,
                "last_input_idx": i,
                "window_index": window_idx,
            })

        return results

    # ========================================================================
    # WINDOW INTERPRETATION - PHASE 2: Horizon-Aware Target Selection
    # ========================================================================
    @staticmethod
    def _interpret_window_for_horizon(
        raw_window: dict,
        all_notes: list[pd.Series],
        horizon: Horizon,
        total_notes: int
    ) -> dict:
        """
        Phase 2 of window generation: Horizon-aware interpretation.

        Takes a raw window and determines the target note and trainability
        for a specific prediction horizon.

        Args:
            raw_window: Dict from _generate_raw_windows containing input_notes and last_input_idx
            all_notes: Complete list of notes for this SID
            horizon: The prediction horizon (H1=1, H2=2, etc.)
            total_notes: Total number of notes in the SID

        Returns:
            Dict containing horizon-specific fields:
                - target_note: The target note for this horizon (or None if not available)
                - trainable: Whether this window is trainable for this horizon
                - target_label: Numeric target label (0/1/2 or -1 if unavailable)
                - target_color: Color code of target (G/Y/R or "" if not trainable)
        """
        last_input_idx = raw_window["last_input_idx"]
        target_idx = last_input_idx + horizon_offset(horizon)

        # Check if target note exists
        if target_idx < total_notes:
            target_note = all_notes[target_idx]
            target_label = target_note.get("target", -1)
            target_color = target_note.get("Overall", "")
        else:
            target_note = None
            target_label = -1
            target_color = ""

        # Trainability requires:
        # 1. Target note exists
        # 2. Input window has exactly 4 notes
        # 3. Target has a valid label (not -1)
        input_notes = raw_window["input_notes"]
        trainable = (
            target_note is not None
            and len(input_notes) == 4
            and target_label in [0, 1, 2]
        )

        # Only include color if trainable
        if not trainable:
            target_color = ""

        return {
            "target_note": target_note,
            "trainable": trainable,
            "target_label": target_label,
            "target_color": target_color,
        }

    # ========================================================================
    # MAIN ENTRY POINT: Multi-Horizon Window Construction
    # ========================================================================
    @staticmethod
    def build_sid_history(state: ScoreCardState) -> None:
        """
        Constructs per-SID sliding windows with multi-horizon targets.

        This is the main entry point for window construction. It supports
        multiple prediction horizons:
            - H1: Predict next card (1 step ahead)
            - H2: Predict card after next (2 steps ahead)

        Column Naming Convention (for backward compatibility):
            - H1 uses original names: `trainable`, `target`, `Color_Code_4`
            - H2 uses suffix: `trainable_h2`, `target_h2`, `Color_Code_h2`

        IMPORTANT SEMANTIC RULE:
            All features and metadata reflect knowledge available at the time
            of the LAST INPUT NOTE (t-1). No metadata is pulled from future notes.

        Window Structure:
            Each row represents a 4-note input window with horizon-specific targets:

            Input Notes     H1 Target    H2 Target    trainable   trainable_h2
            [1,2,3,4]       5            6            True*       True*
            [2,3,4,5]       6            7            True*       True*
            [3,4,5,6]       7            None         True*       False
            [4,5,6,7]       None         None         False       False

            * Requires valid target label (not -1)
        """
        df = state.enriched_df.copy()

        # Group notes by SID in chronological order (already sorted by sid_key)
        sid_to_notes: dict[int, list[pd.Series]] = {}
        for _, row in df.iterrows():
            sid_to_notes.setdefault(row["SID"], []).append(row)

        rows: dict[int, dict] = {}
        key = 0

        for sid, notes in sid_to_notes.items():
            total_notes = len(notes)

            # Phase 1: Generate raw windows (pure chronological slicing)
            raw_windows = ScoreCardTextPrep._generate_raw_windows(notes, max_input_notes=4)

            if not raw_windows:
                continue

            more_than_4 = int(total_notes >= 5)

            # Phase 2: Process each window with horizon interpretation
            for raw_window in raw_windows:
                input_notes = raw_window["input_notes"]
                last_input_note = input_notes[-1]

                # Initialize entry with base metadata
                entry: dict[str, Any] = {
                    "sid": sid,
                    "more_than_4": more_than_4,
                    "total_notes": total_notes,
                }

                # Populate input fields (shared across all horizons)
                color_seq = ""
                main_words_list: list[str] = []

                for j, note in enumerate(input_notes):
                    entry[f"sid_key_{j}"] = note["sid_key"]
                    entry[f"main_words_{j}"] = note["main_words"]
                    entry[f"Color_Code_{j}"] = note["Overall"]
                    color_seq += note["Overall"]
                    main_words_list.append(note["main_words"])

                # Derived input features
                entry["color_set"] = color_seq
                entry["all_green"] = int(len(color_seq) == 4 and color_seq == "GGGG")
                entry["last_sid"] = last_input_note["sid_key"]

                # ====== HORIZON 1 (H1): Use original column names ======
                h1_interp = ScoreCardTextPrep._interpret_window_for_horizon(
                    raw_window, notes, Horizon.H1, total_notes
                )
                entry["trainable"] = h1_interp["trainable"]
                entry["target"] = h1_interp["target_label"]
                entry["Color_Code_4"] = h1_interp["target_color"]

                # Store H1 target note info for RAG/text fields
                if h1_interp["target_note"] is not None:
                    entry["last_note_text"] = h1_interp["target_note"].get("Scorecard_Note", "")
                    entry["last_note_main_words"] = h1_interp["target_note"].get("main_words", "")
                else:
                    entry["last_note_text"] = last_input_note.get("Scorecard_Note", "")
                    entry["last_note_main_words"] = last_input_note.get("main_words", "")

                # ====== HORIZON 2 (H2): Use _h2 suffix ======
                h2_interp = ScoreCardTextPrep._interpret_window_for_horizon(
                    raw_window, notes, Horizon.H2, total_notes
                )
                entry["trainable_h2"] = h2_interp["trainable"]
                entry["target_h2"] = h2_interp["target_label"]
                entry["Color_Code_h2"] = h2_interp["target_color"]

                # Metadata (STRICTLY from last input note - no future leakage)
                entry.update({
                    "LM_Vendor_ID":                last_input_note["LM_Vendor_ID"],
                    "Performance_Management_Type": last_input_note["Performance_Management_Type"],
                    "PO_Complexity_Level":         last_input_note["PO_Complexity_Level"],
                    "PO_Contract_Dollars_Mil":     last_input_note["PO_Contract_Dollars_Mil"],
                    "Supplier_Name":               last_input_note["Supplier_Name"],
                    "LOB_Name":                    last_input_note["LOB_Name"],
                })

                # Construct complete_main_words input string
                vendor = entry["LM_Vendor_ID"]
                lob = f"lob_{entry['LOB_Name'].replace(' ', '_')}"
                name = f"name_{entry['Supplier_Name'].replace(' ', '_')}"
                complexity = f"complexity_{entry['PO_Complexity_Level']}"
                management = f"management_{entry['Performance_Management_Type']}"

                complete_main = " ".join(main_words_list).strip()
                entry["complete_main_words"] = (
                    f"{complete_main} {vendor} {lob} {name} {complexity} {management}".strip()
                )

                rows[key] = entry
                key += 1

        state.sid_df = pd.DataFrame.from_dict(rows, orient="index")

    @staticmethod
    def build_sid_history_two_horizon(state: ScoreCardState) -> None:
        """
        DEPRECATED: Alias for build_sid_history().
        Use build_sid_history() directly for new code.
        """
        ScoreCardTextPrep.build_sid_history(state)

    # ========================================================================
    # DEPRECATED METHODS - Kept for backward compatibility
    # ========================================================================

    @staticmethod
    def build_sid_history_single_horizon(state: ScoreCardState) -> None:
        """
        DEPRECATED: Use build_sid_history() for multi-horizon support.

        Constructs per-SID sliding windows of note history for training and inference (H1 only).
        """
        df = state.enriched_df.copy()

        sid_to_notes = {}
        for _, row in df.iterrows():
            sid_to_notes.setdefault(row["SID"], []).append(row)

        rows = {}
        key = 0

        for sid, notes in sid_to_notes.items():
            total = len(notes)
            windows = ScoreCardTextPrep._generate_note_windows(notes, max_window_size=5)
            more_than_4 = int(total >= 5)

            for window in windows:
                entry = {
                    "sid": sid,
                    "more_than_4": more_than_4,
                    "total_notes": total
                }

                input_notes = window["Input_notes"]
                target_note = window["target_note"]
                last_note = window["last_note"]

                entry["trainable"] = trainable = window["trainable"]

                color_set, main_words_list = ScoreCardTextPrep._populate_input_fields(entry, input_notes)

                fallback_sid = last_note["sid_key"]
                if target_note is not None:
                    populated_target = ScoreCardTextPrep._populate_target_fields(
                        entry,
                        note=target_note,
                        sid_key_fallback=fallback_sid,
                        trainable=trainable
                    )
                else:
                    entry["last_sid"] = fallback_sid
                    entry["target"] = -1
                    entry["Color_Code_4"] = ""
                    entry["last_note_text"] = last_note["Scorecard_Note"]
                    entry["last_note_main_words"] = last_note["main_words"]
                    populated_target = last_note

                meta = {
                    "LM_Vendor_ID":                populated_target["LM_Vendor_ID"],
                    "Performance_Management_Type": populated_target["Performance_Management_Type"],
                    "PO_Complexity_Level":         populated_target["PO_Complexity_Level"],
                    "PO_Contract_Dollars_Mil":     populated_target["PO_Contract_Dollars_Mil"],
                    "Supplier_Name":               populated_target["Supplier_Name"],
                    "LOB_Name":                    populated_target["LOB_Name"]
                }
                entry.update(meta)

                entry["color_set"] = color_set
                entry["all_green"] = int(len(color_set) == 4 and color_set == "G" * 4)

                vendor = meta["LM_Vendor_ID"]
                lob = f"lob_{meta['LOB_Name'].replace(' ', '_')}"
                name = f"name_{meta['Supplier_Name'].replace(' ', '_')}"
                complexity = f"complexity_{meta['PO_Complexity_Level']}"
                management = f"management_{meta['Performance_Management_Type']}"
                complete_main = " ".join(main_words_list).strip()
                entry["complete_main_words"] = f"{complete_main} {vendor} {lob} {name} {complexity} {management}".strip()

                rows[key] = entry
                key += 1

        state.sid_df = pd.DataFrame.from_dict(rows, orient="index")

    @staticmethod
    def _generate_note_windows(notes: list[pd.Series], max_window_size: int = 5) -> list[dict]:
        """
        Returns structured note windows from a list of note rows (pd.Series), for a given SID.
        Used by deprecated build_sid_history_single_horizon method.
        """
        results = []
        n = len(notes)

        for i in range(1, n + 1):
            if i + 1 <= max_window_size:
                window = notes[:i+1]
            else:
                window = notes[i+1 - max_window_size:i+1]

            input_notes = window[:-1]
            last_note = input_notes[-1] if input_notes else None

            if i < n:
                target_note = window[-1]
            else:
                input_notes = notes[-max_window_size + 1:]
                target_note = None
                last_note = input_notes[-1]

            results.append({
                "Input_notes": input_notes,
                "target_note": target_note,
                "last_note": last_note,
                "trainable": not (len(input_notes) < max_window_size - 1 or target_note is None)
            })

        return results

    @staticmethod
    def _populate_input_fields(entry: dict, notes: list) -> tuple[str, list[str]]:
        """Populate input fields from notes list. Used by deprecated methods."""
        color_seq = ""
        main_words_seq = []
        for i, note in enumerate(notes):
            entry[f"sid_key_{i}"] = note["sid_key"]
            entry[f"main_words_{i}"] = note["main_words"]
            color = note["Overall"]
            entry[f"Color_Code_{i}"] = color
            color_seq += color
            main_words_seq.append(note["main_words"])
        return color_seq, main_words_seq

    @staticmethod
    def _populate_target_fields(
        entry: dict,
        note: dict,
        sid_key_fallback: str,
        trainable: bool = True
    ) -> dict:
        """
        Populates target-related fields for the final note in a sliding window.
        Used by deprecated methods.
        """
        entry["last_sid"] = sid_key_fallback
        entry["target"] = note.get("target", -1)
        entry["Color_Code_4"] = note.get("Overall", "") if trainable else ""
        entry["last_note_text"] = note.get("Scorecard_Note", "")
        entry["last_note_main_words"] = note.get("main_words", "")
        return note
