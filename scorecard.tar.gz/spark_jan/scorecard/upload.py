# ========================================================================
# SCORECARD UPLOAD MODULE
# Contains: SQL Server upload pipeline for model predictions
# ========================================================================

import numpy as np
import pandas as pd
from datetime import datetime
from typing import Optional
from urllib.parse import quote_plus

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from .config import ScoreCardConfig


# ========================================================================
# SQL ENGINE CREATION
# ========================================================================

def _odbc_string(config: ScoreCardConfig, driver_token: str) -> str:
    """Build ODBC connection string for SQL Server."""
    return (
        f"DRIVER={{{driver_token}}};"
        f"SERVER={config.sql_server};"
        f"DATABASE={config.sql_database};"
        f"UID={config.sql_uid};"
        f"PWD={config.sql_pwd};"
        "TrustServerCertificate=yes;"
    )


def _make_engine(odbc_str: str) -> Engine:
    """Create SQLAlchemy engine from ODBC string."""
    return create_engine(
        f"mssql+pyodbc:///?odbc_connect={quote_plus(odbc_str)}",
        fast_executemany=True
    )


def get_upload_engine(config: ScoreCardConfig, verbose: bool = True) -> Engine:
    """
    Create a SQLAlchemy engine for uploading to SQL Server.
    Tries multiple driver tokens for compatibility.
    """
    driver_tokens = [config.sql_driver_path, "ODBC Driver 18 for SQL Server"]
    errors = []

    for token in driver_tokens:
        try:
            odbc_str = _odbc_string(config, token)
            engine = _make_engine(odbc_str)
            # Test connection
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            if verbose:
                print(f"[UPLOAD] Connected using driver: {token}")
            return engine
        except Exception as e:
            errors.append((token, repr(e)))

    msg = "\n".join([f" - {tok}: {err}" for tok, err in errors])
    raise RuntimeError(f"Failed to create engine with driver tokens:\n{msg}")


def quick_sql_diagnostics(engine: Engine, table_name: str = "Scorecard_Spark_Model") -> None:
    """Run quick diagnostics on the target SQL table."""
    print(f"[UPLOAD] Running diagnostics on dbo.{table_name}...")
    try:
        with engine.connect() as conn:
            cnt = conn.execute(text(f"SELECT COUNT(*) FROM dbo.{table_name}")).scalar()
            print(f"[UPLOAD]   -> Current row count: {cnt:,}")
    except Exception as e:
        print(f"[UPLOAD]   -> Could not count rows: {e}")


# ========================================================================
# SCHEMA VALIDATION AND TRIMMING
# ========================================================================

def get_schema_info(engine: Engine, table_name: str = "Scorecard_Spark_Model") -> pd.DataFrame:
    """Fetch column schema information from SQL Server."""
    query = f"""
    SELECT
        c.ORDINAL_POSITION,
        c.COLUMN_NAME,
        c.DATA_TYPE,
        c.CHARACTER_MAXIMUM_LENGTH,
        c.IS_NULLABLE
    FROM INFORMATION_SCHEMA.COLUMNS c
    WHERE c.TABLE_SCHEMA = 'dbo' AND c.TABLE_NAME = '{table_name}'
    ORDER BY c.ORDINAL_POSITION
    """
    return pd.read_sql(query, engine)


def build_length_map(schema_df: pd.DataFrame) -> dict[str, int]:
    """Build a column name -> max length mapping for varchar/nvarchar columns."""
    length_map = {}
    for _, row in schema_df.iterrows():
        if row.DATA_TYPE in ("varchar", "nvarchar", "char", "nchar"):
            maxlen = row.CHARACTER_MAXIMUM_LENGTH
            if pd.notna(maxlen) and maxlen > 0:
                length_map[row.COLUMN_NAME] = int(maxlen)
    return length_map


def preflight_report(df: pd.DataFrame, length_map: dict[str, int]) -> pd.DataFrame:
    """
    Check for values that would overflow SQL column lengths.
    Returns a DataFrame with overflow statistics.
    """
    report_rows = []
    for col, maxlen in length_map.items():
        if col not in df.columns:
            continue
        lengths = df[col].fillna("").astype(str).str.len()
        overflow_mask = lengths > maxlen
        overflow_count = overflow_mask.sum()
        max_found = lengths.max()
        report_rows.append({
            "column": col,
            "max_allowed": maxlen,
            "max_found": max_found,
            "overflow_count": overflow_count,
            "status": "OVERFLOW" if overflow_count > 0 else "OK"
        })
    return pd.DataFrame(report_rows)


def forced_trim_with_marker(
    series: pd.Series,
    maxlen: int,
    marker: str = " [TRUNCATED]"
) -> pd.Series:
    """
    Truncate string values to maxlen, adding a marker if truncated.
    """
    def trim_one(val):
        if pd.isna(val):
            return val
        s = str(val)
        if len(s) <= maxlen:
            return s
        cutoff = maxlen - len(marker)
        return s[:cutoff] + marker if cutoff > 0 else s[:maxlen]

    return series.apply(trim_one)


def trim_df_to_schema(
    df: pd.DataFrame,
    length_map: dict[str, int]
) -> tuple[pd.DataFrame, dict[str, int]]:
    """
    Trim all string columns to fit SQL schema.
    Returns (trimmed_df, counts_of_trimmed_values).
    """
    trimmed = df.copy()
    trim_counts = {}

    for col, maxlen in length_map.items():
        if col not in trimmed.columns:
            continue
        before = trimmed[col].fillna("").astype(str)
        overflow_count = (before.str.len() > maxlen).sum()
        if overflow_count > 0:
            trimmed[col] = forced_trim_with_marker(trimmed[col], maxlen)
            trim_counts[col] = overflow_count

    return trimmed, trim_counts


# ========================================================================
# BUILD OUTPUT TABLE FROM PREDICTIONS
# ========================================================================

def build_upload_table(
    df: pd.DataFrame,
    model_number: int,
    verbose: bool = True
) -> pd.DataFrame:
    """
    Transform prediction DataFrame into SQL-ready format.

    Expects df to have columns like:
    - SID, sid_key/last_sid, Report_Date or Note_Year/Note_Month
    - predicted_color or predicted_label
    - prob_green, prob_yellow, prob_red
    - justification or gpt_justification
    - color_set, complete_main_words/main_words
    - sid_key_0, sid_key_1, sid_key_2, sid_key_3
    """
    def best_confidence(row: pd.Series) -> float:
        probs = [
            float(row[c]) for c in ["prob_green", "prob_yellow", "prob_red"]
            if c in row.index and pd.notna(row[c])
        ]
        return max(probs) if probs else np.nan

    def extract_note_sid_from_key(s: pd.Series) -> pd.Series:
        return s.fillna("").astype(str).str.split(".").str[-1].replace("", np.nan)

    # ---------- Choose key for "latest" ----------
    key_col = None
    for c in ["sid_key", "last_sid"]:
        if c in df.columns:
            key_col = c
            break

    if key_col is None:
        required = {"SID", "Note_Year", "Note_Month", "Scorecard_Detail_Note_SID"}
        if required.issubset(df.columns):
            sid_str = df["SID"].astype(int).astype(str).str.zfill(6)
            yr = df["Note_Year"].astype(int).astype(str).str.zfill(4)
            mo = df["Note_Month"].astype(int).astype(str).str.zfill(2)
            note = df["Scorecard_Detail_Note_SID"].astype(int).astype(str).str.zfill(6)
            df = df.assign(_built_sid_key=sid_str + "." + yr + "." + mo + "." + note)
            key_col = "_built_sid_key"
        else:
            raise ValueError(
                "No sid_key/last_sid columns and insufficient parts to construct one."
            )

    # ---------- Latest row per SID ----------
    idx_latest = (
        df.assign(_sortkey=df[key_col].astype(str))
          .groupby("SID")["_sortkey"]
          .idxmax()
    )
    latest = df.loc[idx_latest].copy()
    latest["_Latest"] = True

    # ---------- Derived fields ----------
    sort_cols = (
        ["SID", "Report_Date"] if "Report_Date" in latest.columns
        else ["SID", "Note_Year", "Note_Month"]
    )
    latest = latest.sort_values(sort_cols).reset_index(drop=True)
    latest["_Model_Index"] = np.arange(1, len(latest) + 1)
    latest["_Model_Number"] = model_number

    # Model date
    if "Report_Date" in latest.columns:
        model_date = pd.to_datetime(latest["Report_Date"], errors="coerce").dt.date
    else:
        y = latest.get("Note_Year")
        m = latest.get("Note_Month")
        model_date = pd.to_datetime(
            y.astype("Int64").astype(str).str.zfill(4) + "-" +
            m.astype("Int64").astype(str).str.zfill(2) + "-01",
            errors="coerce"
        ).dt.date
    latest["_Model_Date"] = model_date

    latest["_Scorecard_Detail_SID"] = latest.get("Scorecard_Detail_Note_SID")
    latest["_Color_Set"] = latest.get("color_set")

    latest["_Complete_Main_Words"] = (
        latest["complete_main_words"] if "complete_main_words" in latest.columns
        else latest.get("main_words")
    )

    # Extract note SIDs from sid_key columns
    for i in range(4):
        col_key = f"sid_key_{i}"
        out_col = f"_Scorecard_Detail_Note_SID_{i}"
        if col_key in latest.columns:
            latest[out_col] = extract_note_sid_from_key(latest[col_key]).astype("Int64")
        else:
            latest[out_col] = pd.Series([pd.NA] * len(latest), dtype="Int64")

    # Model prediction (color)
    latest["_Model_Prediction"] = (
        latest["predicted_color"] if "predicted_color" in latest.columns
        else latest.get("predicted_label")
    )

    # Model confidence
    latest["_Model_Confidence"] = latest.apply(best_confidence, axis=1)

    # GPT justification / explanation
    latest["_Model_Explanation"] = (
        latest["justification"]
        if "justification" in latest.columns and latest["justification"].notna().any()
        else latest.get("gpt_justification")
    )

    # Warning / Info
    latest["_Warning"] = ""
    latest["_Info"] = ""

    # Add warning for short color sets
    if "_Color_Set" in latest.columns:
        mask = latest["_Color_Set"].fillna("").str.len() < 4
        latest.loc[mask, "_Warning"] = "Model predicting with less than 4 prior notes"

    # ---------- Final column mapping ----------
    col_map = {
        "_Model_Index": "Model_Index",
        "_Model_Number": "Model_Number",
        "_Model_Date": "Model_Date",
        "_Scorecard_Detail_SID": "Scorecard_Detail_SID",
        "_Color_Set": "Color_Set",
        "_Complete_Main_Words": "Complete_Main_Words",
        "_Scorecard_Detail_Note_SID_0": "Scorecard_Detail_Note_SID_0",
        "_Scorecard_Detail_Note_SID_1": "Scorecard_Detail_Note_SID_1",
        "_Scorecard_Detail_Note_SID_2": "Scorecard_Detail_Note_SID_2",
        "_Scorecard_Detail_Note_SID_3": "Scorecard_Detail_Note_SID_3",
        "_Model_Prediction": "Model_Prediction",
        "_Model_Confidence": "Model_Confidence",
        "_Model_Explanation": "Model_Explanation",
        "_Latest": "Latest",
        "_Warning": "Warning",
        "_Info": "Info",
    }

    out = latest[list(col_map.keys())].rename(columns=col_map)

    if verbose:
        print(f"[UPLOAD] Built upload table: {len(out)} rows")

    return out


# ========================================================================
# MAIN UPLOAD FUNCTION
# ========================================================================

def upload_predictions_to_sql(
    df: pd.DataFrame,
    config: ScoreCardConfig,
    model_number: int,
    table_name: str = "Scorecard_Spark_Model",
    dry_run: bool = False,
    verbose: bool = True
) -> dict:
    """
    Full upload pipeline: transform, validate, trim, and upload predictions to SQL.

    Args:
        df: Prediction DataFrame from the model pipeline
        config: ScoreCardConfig with SQL connection details
        model_number: Model version number to tag the upload
        table_name: Target SQL table name
        dry_run: If True, skip actual upload and just validate
        verbose: Print progress messages

    Returns:
        Dict with upload statistics
    """
    stats = {
        "model_number": model_number,
        "table_name": table_name,
        "dry_run": dry_run,
        "rows_prepared": 0,
        "rows_uploaded": 0,
        "columns_trimmed": {},
        "errors": []
    }

    try:
        # 1. Create engine
        if verbose:
            print(f"[UPLOAD] Connecting to SQL Server...")
        engine = get_upload_engine(config, verbose=verbose)

        # 2. Get schema info
        if verbose:
            print(f"[UPLOAD] Fetching schema for dbo.{table_name}...")
        schema_df = get_schema_info(engine, table_name)
        length_map = build_length_map(schema_df)
        sql_cols = schema_df["COLUMN_NAME"].tolist()

        if verbose:
            print(f"[UPLOAD]   -> {len(sql_cols)} columns in schema")
            print(f"[UPLOAD]   -> {len(length_map)} varchar columns with length limits")

        # 3. Build upload table
        if verbose:
            print(f"[UPLOAD] Transforming predictions to upload format...")
        out_table = build_upload_table(df, model_number, verbose=verbose)
        stats["rows_prepared"] = len(out_table)

        # 4. Align columns to schema
        aligned = out_table.reindex(columns=sql_cols)

        # Normalize types
        if "Model_Date" in aligned.columns:
            aligned["Model_Date"] = (
                pd.to_datetime(aligned["Model_Date"], errors="coerce")
                .dt.date.astype("string").fillna(pd.NA)
            )
        if "Latest" in aligned.columns:
            aligned["Latest"] = (
                aligned["Latest"]
                .map(lambda x: 1 if (isinstance(x, bool) and x)
                     else (1 if str(x).lower() == "true" else 0)
                     if pd.notna(x) else None)
            )

        # 5. Preflight check
        if verbose:
            print(f"[UPLOAD] Running preflight validation...")
        preflight = preflight_report(aligned, length_map)
        overflow_cols = preflight[preflight["status"] == "OVERFLOW"]
        if len(overflow_cols) > 0 and verbose:
            print(f"[UPLOAD]   -> {len(overflow_cols)} columns need trimming")

        # 6. Trim to schema
        trimmed, trim_counts = trim_df_to_schema(aligned, length_map)
        stats["columns_trimmed"] = trim_counts
        if trim_counts and verbose:
            for col, cnt in trim_counts.items():
                print(f"[UPLOAD]   -> Trimmed {cnt} values in '{col}'")

        # 7. Upload
        if dry_run:
            if verbose:
                print(f"[UPLOAD] DRY RUN - skipping actual upload")
            stats["rows_uploaded"] = 0
        else:
            if verbose:
                print(f"[UPLOAD] Uploading {len(trimmed)} rows to dbo.{table_name}...")

            with engine.connect() as conn:
                before = conn.execute(
                    text(f"SELECT COUNT(*) FROM dbo.{table_name}")
                ).scalar()

            trimmed.to_sql(
                name=table_name,
                schema="dbo",
                con=engine,
                if_exists="append",
                index=False,
                chunksize=1000
            )

            with engine.connect() as conn:
                after = conn.execute(
                    text(f"SELECT COUNT(*) FROM dbo.{table_name}")
                ).scalar()

            stats["rows_uploaded"] = after - before
            if verbose:
                print(f"[UPLOAD] Upload complete!")
                print(f"[UPLOAD]   -> Before: {before:,} rows")
                print(f"[UPLOAD]   -> After: {after:,} rows")
                print(f"[UPLOAD]   -> Inserted: {stats['rows_uploaded']:,} rows")

    except Exception as e:
        stats["errors"].append(str(e))
        if verbose:
            print(f"[UPLOAD] ERROR: {e}")
        raise

    return stats
