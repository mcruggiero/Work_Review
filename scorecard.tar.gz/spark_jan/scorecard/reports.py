# ========================================================================
# SCORECARD REPORTS MODULE
# Contains: Dashboard visualizations, flagged prediction analysis,
#           and model validation tools
# ========================================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Optional, Any
from IPython.display import display, Markdown, HTML

# Sklearn imports for model validation
from sklearn.metrics import (
    confusion_matrix, classification_report, accuracy_score,
    precision_recall_curve, average_precision_score,
    roc_curve, auc, brier_score_loss
)
from sklearn.calibration import calibration_curve
from sklearn.preprocessing import label_binarize


# ========================================================================
# DERIVED METRICS HELPERS
# ========================================================================

def normalize_color_letter(color: str) -> str:
    """Convert color name to single letter (Green -> G, Yellow -> Y, Red -> R)."""
    if pd.isna(color):
        return ""
    return str(color).strip()[0].upper()


def movement_score(color_seq: str) -> int:
    """
    Calculate movement score from color sequence.
    Counts total absolute changes in risk level (G=0, Y=1, R=2).
    """
    color_map = {"G": 0, "Y": 1, "R": 2}
    if not color_seq:
        return 0
    nums = [color_map[c] for c in str(color_seq).upper() if c in color_map]
    if len(nums) < 2:
        return 0
    return sum(abs(nums[i] - nums[i-1]) for i in range(1, len(nums)))


def movement_metrics(color_set: str) -> tuple[int, int]:
    """
    Calculate movement metrics from a color sequence.
    Returns (total_changes, max_single_change).
    """
    if pd.isna(color_set) or not color_set:
        return (0, 0)
    color_map = {"G": 0, "Y": 1, "R": 2}
    nums = [color_map.get(c.upper(), -1) for c in str(color_set) if c.upper() in color_map]
    if len(nums) < 2:
        return (0, 0)
    diffs = [abs(nums[i] - nums[i-1]) for i in range(1, len(nums))]
    return (sum(diffs), max(diffs) if diffs else 0)


def compare_trend(last_color: str, pred_color: str) -> str:
    """
    Compare predicted color to last color.
    Returns 'Upgrade', 'Match', or 'Downgrade'.
    """
    order = {"G": 0, "Y": 1, "R": 2}
    last_val = order.get(str(last_color)[0].upper() if last_color else "", 1)
    pred_val = order.get(str(pred_color)[0].upper() if pred_color else "", 1)

    if pred_val < last_val:
        return "Upgrade"
    elif pred_val > last_val:
        return "Downgrade"
    return "Match"


def downgrade(last: str, pred: str) -> bool:
    """Check if prediction is a downgrade (worse rating)."""
    order = {"G": 0, "Y": 1, "R": 2}
    return order.get(pred, 1) > order.get(last, 1)


def upgrade(last: str, pred: str) -> bool:
    """Check if prediction is an upgrade (better rating)."""
    order = {"G": 0, "Y": 1, "R": 2}
    return order.get(pred, 1) < order.get(last, 1)


# ========================================================================
# DATAFRAME ENRICHMENT
# ========================================================================

def enrich_for_reporting(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add derived columns needed for reporting dashboards.

    Expects columns: Model_Prediction, Model_Confidence, Color_Set
    Adds: Pred_First, Last_Color, Prediction_Diff, Flagged, Movement_Score,
          Note_Count, Few_Notes, Pred_vs_Last
    """
    df = df.copy()

    # Normalize predicted color to single letter
    df["Pred_First"] = df["Model_Prediction"].apply(
        lambda x: str(x)[0].upper() if pd.notna(x) else ""
    )

    # Last color from Color_Set
    df["Last_Color"] = df["Color_Set"].apply(
        lambda x: str(x)[-1].upper() if pd.notna(x) and len(str(x)) > 0 else ""
    )

    # Prediction differs from last
    df["Prediction_Diff"] = (df["Pred_First"] != df["Last_Color"]).astype(int)

    # Flagged: low confidence OR prediction differs from last
    df["Flagged"] = (df["Model_Confidence"] < 0.75) | (df["Prediction_Diff"] == 1)

    # Movement score
    df["Movement_Score"] = df["Color_Set"].fillna("").apply(movement_score)

    # Note count (columns starting with Scorecard_Detail_Note_SID_)
    note_cols = [c for c in df.columns if c.startswith("Scorecard_Detail_Note_SID_")]
    if note_cols:
        df["Note_Count"] = df[note_cols].notna().sum(axis=1)
    else:
        df["Note_Count"] = 0

    df["Few_Notes"] = (df["Note_Count"] < 4).astype(int)

    # Upgrade / Match / Downgrade
    df["Pred_vs_Last"] = df.apply(
        lambda row: compare_trend(row["Last_Color"], row["Pred_First"]), axis=1
    )

    return df


# ========================================================================
# SUMMARY STATISTICS
# ========================================================================

def generate_summary_tables(df: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """
    Generate summary tables for the prediction results.
    Returns dict with keys: prediction_counts, flagged_by_pred, confidence_by_flagged, etc.
    """
    df = enrich_for_reporting(df) if "Flagged" not in df.columns else df

    summaries = {}

    # Overall prediction distribution
    summaries["prediction_counts"] = (
        df["Model_Prediction"].value_counts()
        .rename_axis("Prediction")
        .reset_index(name="Count")
    )

    # Flagged vs Not Flagged by prediction
    summaries["flagged_by_prediction"] = (
        pd.crosstab(df["Flagged"], df["Pred_First"])
        .rename(index={False: "Not Flagged", True: "Flagged"})
    )

    # Confidence stats by flagged status
    summaries["confidence_by_flagged"] = (
        df.groupby("Flagged")["Model_Confidence"]
        .agg(["mean", "std", "min", "max", "count"])
        .rename(index={False: "Not Flagged", True: "Flagged"})
    )

    # Low history by flagged status
    summaries["low_history_by_flagged"] = (
        pd.crosstab(df["Flagged"], df["Few_Notes"])
        .rename(columns={0: "Sufficient History", 1: "Low History"})
        .rename(index={False: "Not Flagged", True: "Flagged"})
    )

    # Trend comparison
    summaries["trend_by_flagged"] = (
        pd.crosstab(df["Flagged"], df["Pred_vs_Last"])
        .rename(index={False: "Not Flagged", True: "Flagged"})
    )

    return summaries


# ========================================================================
# VISUALIZATION HELPERS
# ========================================================================

def bar_color_for(letter: str) -> str:
    """Get bar color for prediction letter."""
    return {"G": "green", "Y": "gold", "R": "red"}.get(letter, "gray")


def movement_capped(series: pd.Series) -> pd.Series:
    """Cap movement score at 3+ for binning."""
    return series.clip(upper=3)


def plot_conf_hist(ax, series: pd.Series, title: str, flagged: bool = False) -> None:
    """Plot confidence histogram on given axes."""
    color = "salmon" if flagged else "steelblue"
    ax.hist(series.dropna(), bins=30, color=color, edgecolor="white", alpha=0.8)
    ax.set_yscale("log")
    ax.set_xlabel("Confidence")
    ax.set_ylabel("Frequency (log scale)")
    ax.set_title(title)


def plot_note_counts(ax, subset: pd.DataFrame, title: str) -> None:
    """Plot note count distribution."""
    counts = subset["Note_Count"].value_counts().sort_index()
    colors = ["#2ecc71", "#3498db", "#9b59b6", "#e74c3c", "#f39c12"]
    bars = ax.bar(counts.index, counts.values, color=colors[:len(counts)], edgecolor="white")
    ax.set_xlabel("# Notes Seen")
    ax.set_ylabel("Count")
    ax.set_title(title)


# ========================================================================
# MAIN DASHBOARD PLOT
# ========================================================================

def plot_prediction_dashboard(
    df: pd.DataFrame,
    figsize: tuple[int, int] = (14, 16),
    save_path: Optional[str] = None
) -> plt.Figure:
    """
    Generate a 5x2 dashboard showing prediction analysis.

    Rows:
    1. Predicted color distribution (Not Flagged / Flagged)
    2. Model confidence histograms
    3. Movement score distribution
    4. Note count distribution
    5. Upgrade/Match/Downgrade distribution
    """
    df = enrich_for_reporting(df) if "Flagged" not in df.columns else df

    not_flagged = df[df["Flagged"] == False]
    flagged = df[df["Flagged"] == True]

    label_font = dict(fontsize=12)

    fig, axes = plt.subplots(5, 2, figsize=figsize)
    fig.suptitle("Model Prediction Dashboard", fontsize=16, fontweight="bold", y=0.98)
    plt.subplots_adjust(hspace=0.4, wspace=0.3)

    # -------------------- Row 1: Predicted color counts --------------------
    for idx, (subset, title) in enumerate([
        (not_flagged, "Not Flagged"),
        (flagged, "Flagged")
    ]):
        ax = axes[0, idx]
        color_counts = subset["Pred_First"].value_counts().reindex(["G", "Y", "R"]).fillna(0)
        colors = [bar_color_for(c) for c in color_counts.index]
        bars = ax.bar(color_counts.index, color_counts.values, color=colors, edgecolor="white")
        ax.set_xlabel("Predicted Color", **label_font)
        ax.set_ylabel("Count", **label_font)
        ax.set_title(f"Prediction Distribution ({title})", fontweight="bold")

        # Add value labels
        for bar, val in zip(bars, color_counts.values):
            if val > 0:
                ax.annotate(f"{int(val)}", xy=(bar.get_x() + bar.get_width()/2, bar.get_height()),
                           ha="center", va="bottom", fontsize=10)

    # -------------------- Row 2: Confidence histograms --------------------
    plot_conf_hist(axes[1, 0], not_flagged["Model_Confidence"],
                   "Confidence Distribution (Not Flagged)", flagged=False)
    plot_conf_hist(axes[1, 1], flagged["Model_Confidence"],
                   "Confidence Distribution (Flagged)", flagged=True)

    # -------------------- Row 3: Movement score --------------------
    for idx, (subset, title, color) in enumerate([
        (not_flagged, "Not Flagged", "steelblue"),
        (flagged, "Flagged", "salmon")
    ]):
        ax = axes[2, idx]
        movement = movement_capped(subset["Movement_Score"])
        counts = movement.value_counts().sort_index()
        bars = ax.bar(counts.index, counts.values, color=color, edgecolor="white")
        ax.set_xlabel("Movement Score", **label_font)
        ax.set_ylabel("Frequency (log scale)", **label_font)
        ax.set_yscale("log")
        ax.set_title(f"Color Changes ({title})", fontweight="bold")
        ax.set_xticks([0, 1, 2, 3])
        ax.set_xticklabels(["0", "1", "2", "3+"])

    # -------------------- Row 4: Note counts --------------------
    plot_note_counts(axes[3, 0], not_flagged, "Note Count (Not Flagged)")
    plot_note_counts(axes[3, 1], flagged, "Note Count (Flagged)")

    # -------------------- Row 5: Upgrade/Match/Downgrade --------------------
    for idx, (subset, title) in enumerate([
        (not_flagged, "Not Flagged"),
        (flagged, "Flagged")
    ]):
        ax = axes[4, idx]
        trend_counts = subset["Pred_vs_Last"].value_counts().reindex(
            ["Upgrade", "Match", "Downgrade"]
        ).fillna(0)
        colors = ["green", "steelblue", "red"]
        bars = ax.bar(trend_counts.index, trend_counts.values, color=colors, edgecolor="white")
        ax.set_xlabel("Outcome", **label_font)
        ax.set_ylabel("Count", **label_font)
        ax.set_title(f"Prediction vs Last ({title})", fontweight="bold")

        for bar, val in zip(bars, trend_counts.values):
            if val > 0:
                ax.annotate(f"{int(val)}", xy=(bar.get_x() + bar.get_width()/2, bar.get_height()),
                           ha="center", va="bottom", fontsize=10)

    plt.tight_layout(rect=[0, 0, 1, 0.96])

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"[REPORT] Dashboard saved to: {save_path}")

    return fig


# ========================================================================
# NOTE DISPLAY FUNCTIONS
# ========================================================================

def display_one_note(row: pd.Series) -> None:
    """
    Display a single note prediction in formatted Markdown.
    For use in Jupyter notebooks.
    """
    sid = row.get("Scorecard_Detail_SID", "unknown")
    color = row.get("Model_Prediction", "Unknown")
    color = str(color).strip().title() if pd.notna(color) else "Unknown"

    confidence = f"{100 * float(row.get('Model_Confidence', 0)):.1f}%"
    justification = str(row.get("Model_Explanation", "") or "").strip()
    grade = str(row.get("Pred_vs_Last", "unknown"))

    # Style based on color
    style_map = {
        "Red": '<hr style="border-top: 3px double red;">',
        "Yellow": '<hr style="border-top: 3px double yellow;">',
        "Green": '<hr style="border-top: 3px double green;">'
    }
    style = style_map.get(color, '<hr style="border-top: 3px double green;">')

    md = f"""
{style}

**Scorecard_Detail_SID**: `{sid}`   **Predicted Rating**: **{color}**

---

**Model Confidence**
- **Confidence**: {confidence}
- **Change**: {grade}

{style}

**GPT Justification**
{justification}

"""
    display(Markdown(md))


def display_flagged_notes(
    df: pd.DataFrame,
    max_notes: int = 10,
    sort_by: str = "Model_Confidence",
    ascending: bool = True
) -> None:
    """
    Display flagged notes in formatted Markdown.

    Args:
        df: DataFrame with predictions (will be enriched if needed)
        max_notes: Maximum number of notes to display
        sort_by: Column to sort by
        ascending: Sort order
    """
    df = enrich_for_reporting(df) if "Flagged" not in df.columns else df
    flagged = df[df["Flagged"] == True].copy()

    if len(flagged) == 0:
        display(Markdown("**No flagged predictions found.**"))
        return

    display(Markdown(f"### Flagged Predictions ({len(flagged)} total, showing {min(max_notes, len(flagged))})"))

    flagged = flagged.sort_values(sort_by, ascending=ascending).head(max_notes)

    for _, row in flagged.iterrows():
        display_one_note(row)


# ========================================================================
# HTML REPORT GENERATION
# ========================================================================

def color_rule(color_name: str) -> str:
    """Get CSS color for horizontal rule."""
    return {"Red": "red", "Yellow": "gold", "Green": "green"}.get(color_name, "gray")


def row_to_html_block(row: pd.Series) -> str:
    """Convert a row to an HTML block for report generation."""
    import html as html_lib

    sid = row.get("Scorecard_Detail_SID", "unknown")
    color = str(row.get("Model_Prediction", "Unknown")).strip().title()
    confidence = f"{100 * float(row.get('Model_Confidence', 0)):.1f}%"
    justification = html_lib.escape(str(row.get("Model_Explanation", "") or "")).replace("\n", "<br>")
    grade = str(row.get("Pred_vs_Last", "unknown"))
    rule_color = color_rule(color)

    return f"""
    <div style="margin-bottom: 2em; padding: 1em; border-left: 4px solid {rule_color};">
        <h3 style="color: {rule_color};">SID: {sid} - {color}</h3>
        <p><strong>Confidence:</strong> {confidence} | <strong>Change:</strong> {grade}</p>
        <hr style="border-top: 2px solid {rule_color};">
        <p><strong>GPT Justification:</strong></p>
        <p style="background-color: #f9f9f9; padding: 1em; border-radius: 4px;">{justification}</p>
    </div>
    """


def df_to_html_document(df: pd.DataFrame, title: str = "Flagged Notes Report") -> str:
    """Generate a complete HTML document from a DataFrame of notes."""
    df = enrich_for_reporting(df) if "Flagged" not in df.columns else df

    blocks = []
    for _, row in df.iterrows():
        blocks.append(row_to_html_block(row))

    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>{title}</title>
        <style>
            body {{ font-family: Arial, sans-serif; max-width: 900px; margin: 0 auto; padding: 2em; }}
            h1 {{ color: #333; border-bottom: 2px solid #333; padding-bottom: 0.5em; }}
        </style>
    </head>
    <body>
        <h1>{title}</h1>
        <p>Generated: {pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
        <p>Total notes: {len(df)}</p>
        <hr>
        {"".join(blocks)}
    </body>
    </html>
    """


def save_notes_html(df: pd.DataFrame, path: str) -> str:
    """Save notes to an HTML file."""
    html_content = df_to_html_document(df)
    with open(path, "w", encoding="utf-8") as f:
        f.write(html_content)
    print(f"[REPORT] HTML report saved to: {path}")
    return path


def generate_flagged_report(
    df: pd.DataFrame,
    output_dir: str = ".",
    prefix: str = "flagged_notes"
) -> dict[str, str]:
    """
    Generate full reports for flagged predictions.

    Returns dict with paths to generated files.
    """
    import os
    from datetime import datetime

    df = enrich_for_reporting(df) if "Flagged" not in df.columns else df
    flagged = df[df["Flagged"] == True].copy()

    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    outputs = {}

    # Save HTML report
    html_path = os.path.join(output_dir, f"{prefix}_{timestamp}.html")
    save_notes_html(flagged, html_path)
    outputs["html"] = html_path

    # Save CSV
    csv_path = os.path.join(output_dir, f"{prefix}_{timestamp}.csv")
    flagged.to_csv(csv_path, index=False)
    print(f"[REPORT] CSV export saved to: {csv_path}")
    outputs["csv"] = csv_path

    # Save dashboard image
    fig = plot_prediction_dashboard(df)
    img_path = os.path.join(output_dir, f"dashboard_{timestamp}.png")
    fig.savefig(img_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[REPORT] Dashboard image saved to: {img_path}")
    outputs["dashboard"] = img_path

    return outputs


# ========================================================================
# MODEL VALIDATION - BASELINE COMPARISON
# ========================================================================

def compute_baseline_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    last_colors: np.ndarray,
    class_names: list[str] = None
) -> dict:
    """
    Compute metrics for baselines and model to enable comparison.

    Baselines:
    - Persist: Always predict the last known color
    - Majority: Always predict the most common class

    Args:
        y_true: True labels (0=Green, 1=Yellow, 2=Red)
        y_pred: Model predictions
        last_colors: Last known color for each sample
        class_names: Names for classes

    Returns:
        Dict with accuracy and other metrics for each approach
    """
    if class_names is None:
        class_names = ["Green", "Yellow", "Red"]

    # Model accuracy
    model_acc = accuracy_score(y_true, y_pred)

    # Persist baseline: predict same as last color
    persist_acc = accuracy_score(y_true, last_colors)

    # Majority baseline: always predict most common class
    majority_class = pd.Series(y_true).mode()[0]
    majority_pred = np.full_like(y_true, majority_class)
    majority_acc = accuracy_score(y_true, majority_pred)

    # Compute improvement over baselines
    persist_lift = (model_acc - persist_acc) / persist_acc * 100 if persist_acc > 0 else 0
    majority_lift = (model_acc - majority_acc) / majority_acc * 100 if majority_acc > 0 else 0

    return {
        "model_accuracy": model_acc,
        "persist_accuracy": persist_acc,
        "majority_accuracy": majority_acc,
        "majority_class": class_names[majority_class] if majority_class < len(class_names) else majority_class,
        "lift_over_persist": persist_lift,
        "lift_over_majority": majority_lift,
    }


def plot_baseline_comparison(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    last_colors: np.ndarray,
    class_names: list[str] = None,
    figsize: tuple = (10, 6)
) -> plt.Figure:
    """
    Visualize model performance vs baselines.
    """
    if class_names is None:
        class_names = ["Green", "Yellow", "Red"]

    metrics = compute_baseline_metrics(y_true, y_pred, last_colors, class_names)

    fig, axes = plt.subplots(1, 2, figsize=figsize)

    # Plot 1: Accuracy comparison
    ax1 = axes[0]
    approaches = ["Majority\nBaseline", "Persist\nBaseline", "Model"]
    accuracies = [
        metrics["majority_accuracy"],
        metrics["persist_accuracy"],
        metrics["model_accuracy"]
    ]
    colors = ["#95a5a6", "#f39c12", "#27ae60"]
    bars = ax1.bar(approaches, accuracies, color=colors, edgecolor="white", linewidth=2)

    ax1.set_ylabel("Accuracy", fontsize=12)
    ax1.set_title("Model vs Baselines", fontsize=14, fontweight="bold")
    ax1.set_ylim(0, 1.05)
    ax1.axhline(y=metrics["model_accuracy"], color="#27ae60", linestyle="--", alpha=0.5)

    for bar, acc in zip(bars, accuracies):
        ax1.annotate(f"{acc:.1%}", xy=(bar.get_x() + bar.get_width()/2, bar.get_height()),
                    ha="center", va="bottom", fontsize=12, fontweight="bold")

    # Plot 2: Lift over baselines
    ax2 = axes[1]
    lift_labels = ["vs Majority", "vs Persist"]
    lifts = [metrics["lift_over_majority"], metrics["lift_over_persist"]]
    lift_colors = ["#3498db" if l > 0 else "#e74c3c" for l in lifts]
    bars2 = ax2.bar(lift_labels, lifts, color=lift_colors, edgecolor="white", linewidth=2)

    ax2.set_ylabel("Improvement (%)", fontsize=12)
    ax2.set_title("Model Lift Over Baselines", fontsize=14, fontweight="bold")
    ax2.axhline(y=0, color="black", linestyle="-", linewidth=0.5)

    for bar, lift in zip(bars2, lifts):
        va = "bottom" if lift >= 0 else "top"
        ax2.annotate(f"{lift:+.1f}%", xy=(bar.get_x() + bar.get_width()/2, bar.get_height()),
                    ha="center", va=va, fontsize=12, fontweight="bold")

    plt.tight_layout()
    return fig


# ========================================================================
# MODEL VALIDATION - CALIBRATION ANALYSIS
# ========================================================================

def compute_calibration_metrics(
    y_true: np.ndarray,
    y_proba: np.ndarray,
    n_bins: int = 10
) -> dict:
    """
    Compute calibration metrics for multi-class predictions.

    Args:
        y_true: True labels (0, 1, 2)
        y_proba: Predicted probabilities (n_samples, 3)
        n_bins: Number of bins for calibration curve

    Returns:
        Dict with calibration metrics per class and overall Brier score
    """
    n_classes = y_proba.shape[1] if len(y_proba.shape) > 1 else 3
    class_names = ["Green", "Yellow", "Red"][:n_classes]

    # Binarize true labels
    y_true_bin = label_binarize(y_true, classes=list(range(n_classes)))
    if n_classes == 2:
        y_true_bin = np.hstack([1 - y_true_bin, y_true_bin])

    calibration_data = {}
    brier_scores = {}

    for i, class_name in enumerate(class_names):
        # Get probabilities for this class
        if len(y_proba.shape) > 1:
            proba_class = y_proba[:, i]
        else:
            proba_class = (y_proba == i).astype(float)

        true_class = y_true_bin[:, i]

        # Calibration curve
        try:
            prob_true, prob_pred = calibration_curve(true_class, proba_class, n_bins=n_bins, strategy='uniform')
            calibration_data[class_name] = {
                "prob_true": prob_true,
                "prob_pred": prob_pred
            }
        except Exception:
            calibration_data[class_name] = None

        # Brier score
        brier_scores[class_name] = brier_score_loss(true_class, proba_class)

    # Overall Brier score (mean across classes)
    overall_brier = np.mean(list(brier_scores.values()))

    return {
        "calibration_curves": calibration_data,
        "brier_scores": brier_scores,
        "overall_brier": overall_brier
    }


def plot_calibration_curves(
    y_true: np.ndarray,
    y_proba: np.ndarray,
    n_bins: int = 10,
    figsize: tuple = (14, 5)
) -> plt.Figure:
    """
    Plot calibration curves for each class.
    """
    class_names = ["Green", "Yellow", "Red"]
    class_colors = ["#27ae60", "#f1c40f", "#e74c3c"]

    metrics = compute_calibration_metrics(y_true, y_proba, n_bins)

    fig, axes = plt.subplots(1, 3, figsize=figsize)
    fig.suptitle("Calibration Curves by Class", fontsize=14, fontweight="bold")

    for idx, (class_name, color) in enumerate(zip(class_names, class_colors)):
        ax = axes[idx]

        # Perfect calibration line
        ax.plot([0, 1], [0, 1], "k--", label="Perfect", alpha=0.7)

        cal_data = metrics["calibration_curves"].get(class_name)
        if cal_data is not None:
            ax.plot(cal_data["prob_pred"], cal_data["prob_true"],
                   "s-", color=color, label=f"{class_name}", linewidth=2, markersize=8)

        brier = metrics["brier_scores"].get(class_name, 0)
        ax.set_xlabel("Mean Predicted Probability", fontsize=11)
        ax.set_ylabel("Fraction of Positives", fontsize=11)
        ax.set_title(f"{class_name}\nBrier Score: {brier:.4f}", fontsize=12)
        ax.legend(loc="lower right")
        ax.set_xlim(-0.05, 1.05)
        ax.set_ylim(-0.05, 1.05)
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    return fig


# ========================================================================
# MODEL VALIDATION - PRECISION-RECALL CURVES
# ========================================================================

def plot_precision_recall_curves(
    y_true: np.ndarray,
    y_proba: np.ndarray,
    figsize: tuple = (14, 5)
) -> plt.Figure:
    """
    Plot precision-recall curves for each class.
    Especially important for imbalanced classes like Yellow and Red.
    """
    class_names = ["Green", "Yellow", "Red"]
    class_colors = ["#27ae60", "#f1c40f", "#e74c3c"]

    n_classes = len(class_names)
    y_true_bin = label_binarize(y_true, classes=list(range(n_classes)))
    if n_classes == 2:
        y_true_bin = np.hstack([1 - y_true_bin, y_true_bin])

    fig, axes = plt.subplots(1, 3, figsize=figsize)
    fig.suptitle("Precision-Recall Curves by Class", fontsize=14, fontweight="bold")

    for idx, (class_name, color) in enumerate(zip(class_names, class_colors)):
        ax = axes[idx]

        if len(y_proba.shape) > 1:
            proba_class = y_proba[:, idx]
        else:
            proba_class = (y_proba == idx).astype(float)

        true_class = y_true_bin[:, idx]

        # Compute PR curve
        precision, recall, _ = precision_recall_curve(true_class, proba_class)
        ap = average_precision_score(true_class, proba_class)

        # Plot
        ax.plot(recall, precision, color=color, linewidth=2, label=f"AP = {ap:.3f}")
        ax.fill_between(recall, precision, alpha=0.2, color=color)

        # Baseline (random classifier)
        baseline = true_class.sum() / len(true_class)
        ax.axhline(y=baseline, color="gray", linestyle="--", alpha=0.7, label=f"Baseline = {baseline:.3f}")

        ax.set_xlabel("Recall", fontsize=11)
        ax.set_ylabel("Precision", fontsize=11)
        ax.set_title(f"{class_name}", fontsize=12, fontweight="bold")
        ax.legend(loc="lower left")
        ax.set_xlim(-0.05, 1.05)
        ax.set_ylim(-0.05, 1.05)
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    return fig


# ========================================================================
# MODEL VALIDATION - TEMPORAL ANALYSIS
# ========================================================================

def temporal_train_test_split(
    df: pd.DataFrame,
    date_col: str,
    test_ratio: float = 0.2
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Split data by time - train on earlier data, test on later.

    Args:
        df: DataFrame with predictions
        date_col: Column containing date/time info
        test_ratio: Fraction of data to use for testing (most recent)

    Returns:
        (train_df, test_df)
    """
    df_sorted = df.sort_values(date_col).reset_index(drop=True)
    split_idx = int(len(df_sorted) * (1 - test_ratio))

    train_df = df_sorted.iloc[:split_idx].copy()
    test_df = df_sorted.iloc[split_idx:].copy()

    return train_df, test_df


def analyze_temporal_performance(
    df: pd.DataFrame,
    date_col: str,
    true_col: str,
    pred_col: str,
    n_periods: int = 5
) -> pd.DataFrame:
    """
    Analyze model performance across time periods.

    Args:
        df: DataFrame with predictions
        date_col: Column containing date/time info
        true_col: Column with true labels
        pred_col: Column with predictions
        n_periods: Number of time periods to analyze

    Returns:
        DataFrame with performance metrics per period
    """
    df_sorted = df.sort_values(date_col).reset_index(drop=True)

    # Split into periods
    period_size = len(df_sorted) // n_periods

    results = []
    for i in range(n_periods):
        start_idx = i * period_size
        end_idx = start_idx + period_size if i < n_periods - 1 else len(df_sorted)

        period_df = df_sorted.iloc[start_idx:end_idx]

        if len(period_df) == 0:
            continue

        y_true = period_df[true_col].values
        y_pred = period_df[pred_col].values

        # Filter to valid predictions
        valid_mask = pd.notna(y_true) & pd.notna(y_pred)
        if valid_mask.sum() == 0:
            continue

        y_true = y_true[valid_mask]
        y_pred = y_pred[valid_mask]

        acc = accuracy_score(y_true, y_pred)

        # Get date range
        date_min = period_df[date_col].min()
        date_max = period_df[date_col].max()

        results.append({
            "period": i + 1,
            "date_start": date_min,
            "date_end": date_max,
            "n_samples": len(period_df),
            "accuracy": acc
        })

    return pd.DataFrame(results)


def plot_temporal_performance(
    df: pd.DataFrame,
    date_col: str,
    true_col: str,
    pred_col: str,
    n_periods: int = 5,
    figsize: tuple = (12, 5)
) -> plt.Figure:
    """
    Visualize model performance over time.
    """
    perf_df = analyze_temporal_performance(df, date_col, true_col, pred_col, n_periods)

    if len(perf_df) == 0:
        fig, ax = plt.subplots(figsize=figsize)
        ax.text(0.5, 0.5, "Insufficient data for temporal analysis",
                ha="center", va="center", fontsize=14)
        return fig

    fig, axes = plt.subplots(1, 2, figsize=figsize)

    # Plot 1: Accuracy over time
    ax1 = axes[0]
    ax1.plot(perf_df["period"], perf_df["accuracy"], "bo-", linewidth=2, markersize=10)
    ax1.fill_between(perf_df["period"], perf_df["accuracy"], alpha=0.2)
    ax1.axhline(y=perf_df["accuracy"].mean(), color="red", linestyle="--",
                label=f"Mean: {perf_df['accuracy'].mean():.3f}")
    ax1.set_xlabel("Time Period", fontsize=12)
    ax1.set_ylabel("Accuracy", fontsize=12)
    ax1.set_title("Model Accuracy Over Time", fontsize=14, fontweight="bold")
    ax1.legend()
    ax1.set_ylim(0, 1.05)
    ax1.grid(True, alpha=0.3)

    # Plot 2: Sample size over time
    ax2 = axes[1]
    ax2.bar(perf_df["period"], perf_df["n_samples"], color="#3498db", edgecolor="white")
    ax2.set_xlabel("Time Period", fontsize=12)
    ax2.set_ylabel("Number of Samples", fontsize=12)
    ax2.set_title("Sample Size per Period", fontsize=14, fontweight="bold")
    ax2.grid(True, alpha=0.3, axis="y")

    plt.tight_layout()
    return fig


# ========================================================================
# MODEL VALIDATION - ERROR ANALYSIS
# ========================================================================

def analyze_errors(
    df: pd.DataFrame,
    true_col: str,
    pred_col: str,
    confidence_col: str,
    class_names: list[str] = None
) -> dict:
    """
    Analyze prediction errors in detail.

    Args:
        df: DataFrame with predictions
        true_col: Column with true labels
        pred_col: Column with predicted labels
        confidence_col: Column with prediction confidence
        class_names: Names for classes

    Returns:
        Dict with error analysis results
    """
    if class_names is None:
        class_names = ["Green", "Yellow", "Red"]

    df = df.copy()

    # Filter to valid predictions
    valid_mask = df[true_col].notna() & df[pred_col].notna()
    df = df[valid_mask]

    # Identify errors
    df["is_error"] = df[true_col] != df[pred_col]
    df["error_type"] = df.apply(
        lambda row: f"{class_names[int(row[true_col])]} -> {class_names[int(row[pred_col])]}"
        if row["is_error"] else "Correct",
        axis=1
    )

    errors_df = df[df["is_error"]].copy()

    # Error statistics
    total_errors = len(errors_df)
    total_samples = len(df)
    error_rate = total_errors / total_samples if total_samples > 0 else 0

    # Error breakdown by type
    error_type_counts = errors_df["error_type"].value_counts().to_dict()

    # High-confidence errors (most concerning)
    high_conf_threshold = 0.8
    high_conf_errors = errors_df[errors_df[confidence_col] >= high_conf_threshold]

    # Confidence distribution of errors vs correct
    correct_df = df[~df["is_error"]]

    return {
        "total_errors": total_errors,
        "total_samples": total_samples,
        "error_rate": error_rate,
        "error_type_counts": error_type_counts,
        "high_confidence_errors": len(high_conf_errors),
        "high_conf_error_rate": len(high_conf_errors) / total_errors if total_errors > 0 else 0,
        "errors_df": errors_df,
        "high_conf_errors_df": high_conf_errors,
        "mean_conf_errors": errors_df[confidence_col].mean() if len(errors_df) > 0 else 0,
        "mean_conf_correct": correct_df[confidence_col].mean() if len(correct_df) > 0 else 0,
    }


def plot_error_analysis(
    df: pd.DataFrame,
    true_col: str,
    pred_col: str,
    confidence_col: str,
    class_names: list[str] = None,
    figsize: tuple = (14, 10)
) -> plt.Figure:
    """
    Visualize error analysis results.
    """
    if class_names is None:
        class_names = ["Green", "Yellow", "Red"]

    analysis = analyze_errors(df, true_col, pred_col, confidence_col, class_names)

    fig, axes = plt.subplots(2, 2, figsize=figsize)
    fig.suptitle("Error Analysis", fontsize=16, fontweight="bold")

    # Plot 1: Error type breakdown
    ax1 = axes[0, 0]
    error_counts = analysis["error_type_counts"]
    if error_counts:
        labels = list(error_counts.keys())
        values = list(error_counts.values())
        colors = plt.cm.Reds(np.linspace(0.3, 0.8, len(labels)))
        bars = ax1.barh(labels, values, color=colors)
        ax1.set_xlabel("Count")
        ax1.set_title("Error Types (True -> Predicted)", fontsize=12, fontweight="bold")
        for bar, val in zip(bars, values):
            ax1.annotate(f"{val}", xy=(bar.get_width(), bar.get_y() + bar.get_height()/2),
                        ha="left", va="center", fontsize=10)
    else:
        ax1.text(0.5, 0.5, "No errors found!", ha="center", va="center", fontsize=14)
        ax1.set_title("Error Types", fontsize=12, fontweight="bold")

    # Plot 2: Confidence distribution - Errors vs Correct
    ax2 = axes[0, 1]
    valid_mask = df[true_col].notna() & df[pred_col].notna() & df[confidence_col].notna()
    df_valid = df[valid_mask].copy()
    df_valid["is_error"] = df_valid[true_col] != df_valid[pred_col]

    correct_conf = df_valid[~df_valid["is_error"]][confidence_col]
    error_conf = df_valid[df_valid["is_error"]][confidence_col]

    if len(correct_conf) > 0:
        ax2.hist(correct_conf, bins=20, alpha=0.7, label=f"Correct (n={len(correct_conf)})", color="#27ae60")
    if len(error_conf) > 0:
        ax2.hist(error_conf, bins=20, alpha=0.7, label=f"Errors (n={len(error_conf)})", color="#e74c3c")

    ax2.set_xlabel("Confidence")
    ax2.set_ylabel("Frequency")
    ax2.set_title("Confidence Distribution", fontsize=12, fontweight="bold")
    ax2.legend()
    ax2.axvline(x=0.8, color="black", linestyle="--", alpha=0.5, label="High Conf Threshold")

    # Plot 3: High-confidence errors
    ax3 = axes[1, 0]
    high_conf_df = analysis["high_conf_errors_df"]
    if len(high_conf_df) > 0:
        high_conf_types = high_conf_df["error_type"].value_counts()
        colors = plt.cm.Oranges(np.linspace(0.4, 0.9, len(high_conf_types)))
        ax3.pie(high_conf_types.values, labels=high_conf_types.index, colors=colors,
               autopct='%1.1f%%', startangle=90)
        ax3.set_title(f"High-Confidence Errors (n={len(high_conf_df)})\nConf >= 80%",
                     fontsize=12, fontweight="bold")
    else:
        ax3.text(0.5, 0.5, "No high-confidence errors!", ha="center", va="center", fontsize=14)
        ax3.set_title("High-Confidence Errors", fontsize=12, fontweight="bold")

    # Plot 4: Summary statistics
    ax4 = axes[1, 1]
    ax4.axis("off")

    summary_text = f"""
    ERROR ANALYSIS SUMMARY
    ----------------------
    Total Samples: {analysis['total_samples']:,}
    Total Errors: {analysis['total_errors']:,}
    Error Rate: {analysis['error_rate']:.2%}

    High-Confidence Errors: {analysis['high_confidence_errors']:,}
    (Conf >= 80%)

    Mean Confidence:
      - Correct Predictions: {analysis['mean_conf_correct']:.3f}
      - Error Predictions: {analysis['mean_conf_errors']:.3f}
    """
    ax4.text(0.1, 0.5, summary_text, fontsize=12, family="monospace",
            verticalalignment="center", transform=ax4.transAxes)
    ax4.set_title("Summary", fontsize=12, fontweight="bold")

    plt.tight_layout()
    return fig


# ========================================================================
# MODEL VALIDATION - FEATURE IMPORTANCE
# ========================================================================

def extract_feature_importance(
    model: Any,
    feature_names: list[str],
    top_n: int = 20
) -> dict:
    """
    Extract feature importance from a trained model.

    Args:
        model: Trained sklearn model (must have coef_ or feature_importances_)
        feature_names: List of feature names
        top_n: Number of top features to return per class

    Returns:
        Dict with feature importance data
    """
    results = {}

    # Try to get coefficients (for linear models like LogisticRegression)
    if hasattr(model, "coef_"):
        coef = model.coef_
        class_names = ["Green", "Yellow", "Red"]

        for i, class_name in enumerate(class_names):
            if i < len(coef):
                class_coef = coef[i]

                # Get top positive and negative coefficients
                top_pos_idx = np.argsort(class_coef)[-top_n:][::-1]
                top_neg_idx = np.argsort(class_coef)[:top_n]

                results[class_name] = {
                    "top_positive": [(feature_names[j], class_coef[j]) for j in top_pos_idx if j < len(feature_names)],
                    "top_negative": [(feature_names[j], class_coef[j]) for j in top_neg_idx if j < len(feature_names)],
                }

    # Try to get feature importances (for tree-based models)
    elif hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
        top_idx = np.argsort(importances)[-top_n:][::-1]

        results["overall"] = {
            "top_features": [(feature_names[j], importances[j]) for j in top_idx if j < len(feature_names)]
        }

    return results


def plot_feature_importance(
    model: Any,
    feature_names: list[str],
    top_n: int = 15,
    figsize: tuple = (14, 10)
) -> plt.Figure:
    """
    Visualize feature importance / coefficients.
    """
    importance = extract_feature_importance(model, feature_names, top_n)

    if not importance:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.text(0.5, 0.5, "Could not extract feature importance from model",
               ha="center", va="center", fontsize=14)
        return fig

    class_names = ["Green", "Yellow", "Red"]
    class_colors = ["#27ae60", "#f1c40f", "#e74c3c"]

    # Check if we have per-class coefficients or overall importance
    if "overall" in importance:
        # Single importance ranking (tree-based models)
        fig, ax = plt.subplots(figsize=(10, 8))

        features = importance["overall"]["top_features"]
        names = [f[0] for f in features]
        values = [f[1] for f in features]

        y_pos = np.arange(len(names))
        ax.barh(y_pos, values, color="#3498db")
        ax.set_yticks(y_pos)
        ax.set_yticklabels(names)
        ax.set_xlabel("Importance")
        ax.set_title("Top Feature Importance", fontsize=14, fontweight="bold")
        ax.invert_yaxis()

    else:
        # Per-class coefficients (linear models)
        fig, axes = plt.subplots(1, 3, figsize=figsize)
        fig.suptitle("Top Predictive Words by Class", fontsize=16, fontweight="bold")

        for idx, (class_name, color) in enumerate(zip(class_names, class_colors)):
            ax = axes[idx]

            if class_name not in importance:
                ax.text(0.5, 0.5, f"No data for {class_name}", ha="center", va="center")
                continue

            # Combine positive and negative, show top by absolute value
            pos_features = importance[class_name]["top_positive"]
            neg_features = importance[class_name]["top_negative"]

            all_features = pos_features + neg_features
            # Sort by absolute value
            all_features = sorted(all_features, key=lambda x: abs(x[1]), reverse=True)[:top_n]

            names = [f[0][:30] for f in all_features]  # Truncate long names
            values = [f[1] for f in all_features]
            colors_bar = [color if v > 0 else "#95a5a6" for v in values]

            y_pos = np.arange(len(names))
            ax.barh(y_pos, values, color=colors_bar)
            ax.set_yticks(y_pos)
            ax.set_yticklabels(names, fontsize=9)
            ax.set_xlabel("Coefficient")
            ax.set_title(f"{class_name}", fontsize=12, fontweight="bold")
            ax.axvline(x=0, color="black", linestyle="-", linewidth=0.5)
            ax.invert_yaxis()

    plt.tight_layout()
    return fig


def generate_word_clouds(
    model: Any,
    feature_names: list[str],
    top_n: int = 100,
    figsize: tuple = (15, 5)
) -> plt.Figure:
    """
    Generate word clouds for each class based on feature coefficients.
    Requires wordcloud package.
    """
    try:
        from wordcloud import WordCloud
    except ImportError:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.text(0.5, 0.5, "wordcloud package not installed\npip install wordcloud",
               ha="center", va="center", fontsize=14)
        return fig

    importance = extract_feature_importance(model, feature_names, top_n)

    if not importance or "overall" in importance:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.text(0.5, 0.5, "Word clouds require per-class coefficients (linear model)",
               ha="center", va="center", fontsize=14)
        return fig

    class_names = ["Green", "Yellow", "Red"]
    class_colors = ["Greens", "YlOrBr", "Reds"]

    fig, axes = plt.subplots(1, 3, figsize=figsize)
    fig.suptitle("Predictive Word Clouds by Class", fontsize=16, fontweight="bold")

    for idx, (class_name, cmap) in enumerate(zip(class_names, class_colors)):
        ax = axes[idx]

        if class_name not in importance:
            ax.text(0.5, 0.5, f"No data for {class_name}", ha="center", va="center")
            ax.axis("off")
            continue

        # Use positive coefficients for word cloud
        pos_features = importance[class_name]["top_positive"]

        if not pos_features:
            ax.text(0.5, 0.5, f"No positive features for {class_name}", ha="center", va="center")
            ax.axis("off")
            continue

        word_freq = {f[0]: max(0, f[1]) for f in pos_features}

        wc = WordCloud(
            width=400, height=300,
            background_color="white",
            colormap=cmap,
            max_words=50
        ).generate_from_frequencies(word_freq)

        ax.imshow(wc, interpolation="bilinear")
        ax.axis("off")
        ax.set_title(f"{class_name}", fontsize=12, fontweight="bold")

    plt.tight_layout()
    return fig


# ========================================================================
# COMPREHENSIVE MODEL VALIDATION REPORT
# ========================================================================

def generate_model_validation_report(
    df: pd.DataFrame,
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_proba: np.ndarray,
    last_colors: np.ndarray,
    model: Any = None,
    feature_names: list[str] = None,
    date_col: str = None,
    output_dir: str = None,
    verbose: bool = True
) -> dict:
    """
    Generate a comprehensive model validation report.

    Args:
        df: Full DataFrame with predictions
        y_true: True labels
        y_pred: Predicted labels
        y_proba: Predicted probabilities (n_samples, 3)
        last_colors: Last known colors for baseline comparison
        model: Trained model (optional, for feature importance)
        feature_names: Feature names (optional, for feature importance)
        date_col: Date column for temporal analysis (optional)
        output_dir: Directory to save figures (optional)
        verbose: Print progress

    Returns:
        Dict with all validation metrics and figures
    """
    import os

    results = {}
    figures = {}

    if verbose:
        print("=" * 60)
        print("GENERATING MODEL VALIDATION REPORT")
        print("=" * 60)

    # 1. Baseline Comparison
    if verbose:
        print("\n[1/6] Computing baseline comparison...")
    results["baselines"] = compute_baseline_metrics(y_true, y_pred, last_colors)
    figures["baseline_comparison"] = plot_baseline_comparison(y_true, y_pred, last_colors)

    if verbose:
        print(f"  Model Accuracy: {results['baselines']['model_accuracy']:.4f}")
        print(f"  Persist Baseline: {results['baselines']['persist_accuracy']:.4f}")
        print(f"  Lift over Persist: {results['baselines']['lift_over_persist']:+.1f}%")

    # 2. Calibration Analysis
    if verbose:
        print("\n[2/6] Computing calibration metrics...")
    results["calibration"] = compute_calibration_metrics(y_true, y_proba)
    figures["calibration_curves"] = plot_calibration_curves(y_true, y_proba)

    if verbose:
        print(f"  Overall Brier Score: {results['calibration']['overall_brier']:.4f}")

    # 3. Precision-Recall Curves
    if verbose:
        print("\n[3/6] Computing precision-recall curves...")
    figures["pr_curves"] = plot_precision_recall_curves(y_true, y_proba)

    # 4. Temporal Analysis
    if date_col is not None and date_col in df.columns:
        if verbose:
            print("\n[4/6] Analyzing temporal performance...")

        # Create temp columns for analysis
        df_temp = df.copy()
        df_temp["_true"] = y_true
        df_temp["_pred"] = y_pred

        results["temporal"] = analyze_temporal_performance(
            df_temp, date_col, "_true", "_pred", n_periods=5
        ).to_dict("records")
        figures["temporal"] = plot_temporal_performance(
            df_temp, date_col, "_true", "_pred", n_periods=5
        )
    else:
        if verbose:
            print("\n[4/6] Skipping temporal analysis (no date column)")
        results["temporal"] = None

    # 5. Error Analysis
    if verbose:
        print("\n[5/6] Analyzing errors...")

    df_temp = df.copy()
    df_temp["_true"] = y_true
    df_temp["_pred"] = y_pred
    df_temp["_conf"] = y_proba.max(axis=1) if len(y_proba.shape) > 1 else y_proba

    error_results = analyze_errors(df_temp, "_true", "_pred", "_conf")
    results["errors"] = {k: v for k, v in error_results.items()
                        if k not in ["errors_df", "high_conf_errors_df"]}
    figures["error_analysis"] = plot_error_analysis(df_temp, "_true", "_pred", "_conf")

    if verbose:
        print(f"  Total Errors: {results['errors']['total_errors']}")
        print(f"  High-Confidence Errors: {results['errors']['high_confidence_errors']}")

    # 6. Feature Importance
    if model is not None and feature_names is not None:
        if verbose:
            print("\n[6/6] Extracting feature importance...")
        results["feature_importance"] = extract_feature_importance(model, feature_names)
        figures["feature_importance"] = plot_feature_importance(model, feature_names)

        try:
            figures["word_clouds"] = generate_word_clouds(model, feature_names)
        except Exception as e:
            if verbose:
                print(f"  Could not generate word clouds: {e}")
    else:
        if verbose:
            print("\n[6/6] Skipping feature importance (no model/features provided)")

    # Save figures if output_dir provided
    if output_dir is not None:
        os.makedirs(output_dir, exist_ok=True)
        for name, fig in figures.items():
            path = os.path.join(output_dir, f"validation_{name}.png")
            fig.savefig(path, dpi=150, bbox_inches="tight")
            if verbose:
                print(f"  Saved: {path}")

    if verbose:
        print("\n" + "=" * 60)
        print("VALIDATION REPORT COMPLETE")
        print("=" * 60)

    return {"metrics": results, "figures": figures}
