# ========================================================================
# SCORECARD CONFIG MODULE
# Contains: ScoreCardConfig, ScoreCardState, Horizon enum
# ========================================================================

import os
import json
import spacy
from spacy.cli import download as spacy_download
from typing import Any, Literal, Optional
from dataclasses import dataclass, field
from enum import IntEnum
from pathlib import Path

import pandas as pd
from sentence_transformers import SentenceTransformer


# ========================================================================
# BASE PATH CALCULATION
# This ensures file paths work regardless of where Python is run from.
# _PACKAGE_DIR = .../spark_jan/scorecard/
# _PROJECT_ROOT = .../spark_jan/
# ========================================================================
_PACKAGE_DIR = Path(__file__).parent.resolve()
_PROJECT_ROOT = _PACKAGE_DIR.parent


def _resolve_path(relative_path: str) -> str:
    """Convert a project-relative path to an absolute path."""
    return str(_PROJECT_ROOT / relative_path)


# ========================================================================
# HORIZON TYPE SYSTEM - Multi-horizon prediction support
# ========================================================================
class Horizon(IntEnum):
    """
    Prediction horizon for the ScoreCard model.

    H1: Predict the next card (1 step ahead)
    H2: Predict the card after next (2 steps ahead)

    To add H3: simply add H3 = 3 here and to SUPPORTED_HORIZONS.
    """
    H1 = 1  # Next card
    H2 = 2  # Card after next


# List of horizons to train models for
SUPPORTED_HORIZONS: list[Horizon] = [Horizon.H1, Horizon.H2]


def horizon_offset(h: Horizon) -> int:
    """
    Return the temporal offset for a given horizon.
    H1 -> 1 (next note), H2 -> 2 (note after next), etc.
    """
    return int(h)


@dataclass
class ScoreCardConfig:
    # ==========================================================================
    # GLOBAL CONFIG / EXECUTION SETTINGS
    # NOTE: File paths use _resolve_path() to work from any working directory
    # ==========================================================================
    spacy_model:            str = "en_core_web_trf"
    json_path:              str = field(default_factory=lambda: _resolve_path("scorecard_state/state.json"))
    model_matrix_json:      str = field(default_factory=lambda: _resolve_path("prompts/model_matrix.json"))
    vectorizer_strategy:    Literal["count", "tfidf", "binary"] = "count"

    # ==========================================================================
    # SQL CONNECTION SETTINGS
    # ==========================================================================
    sql_driver_path:        str = "/home/jovyan/local/msodbcsql18/opt/microsoft/msodbcsql18/lib64/libmsodbcsql-18.3.so.2.1"
    sql_server:             str = "Nestler.us.lmco.com"
    sql_database:           str = "SubcontractScorecard"
    sql_uid:                str = "ACE_TEAM"
    sql_pwd:                str = "##########"
    sql_query_file:         str = field(default_factory=lambda: _resolve_path("prompts/sql_query.txt"))

    # ==========================================================================
    # EXECUTION SWITCHES (enable/disable pipeline stages)
    # ==========================================================================
    require_gpu:        bool = True
    sql_download:       bool = True
    enable_nlp:         bool = True
    build_models:       bool = True
    run_predictions:    bool = True
    build_rag:          bool = True

    # ==========================================================================
    # ELASTICSEARCH CONFIGURATION
    # ==========================================================================
    es_host:                str = "http://localhost:9200"
    elastic_index:          str = "scorecard"
    tokenizer_name:         str = "cl100k_base"

    # ==========================================================================
    # EMBEDDING MODEL CONFIGURATION
    # ==========================================================================
    embedding_model_name:   str = "BAAI/bge-large-en-v1.5"
    embedding_vector_dim:   int = 1024
    rag_index:              str = "scorecard_rag_notes"
    batch_size:             int = 128

    # ==========================================================================
    # Modeling
    # ==========================================================================
    training_length:        int = 5

    # Default model keys for each horizon. These specify which model configuration
    # to use when running predictions. Format: "feature_set | sampling | vectorizer | class_weights"
    # Set to None to use find_best_model() instead of a predetermined key.
    default_model_key_h1:   Optional[str] = "complete_main_words_only | no_downsample_weighted | count | {0: 0.5, 1: 1.35, 2: 1.15}"
    default_model_key_h2:   Optional[str] = "complete_main_words_only | no_downsample_weighted | count | {0: 0.5, 1: 1.35, 2: 1.15}"

    # ==========================================================================
    # GPT CONFIGURATION
    # ==========================================================================
    gpt_prompt_location:    str = field(default_factory=lambda: _resolve_path("prompts/GPT_Prompt.txt"))
    gpt_base_url:           str = "https://api.ai.us.lmco.com/v1/"

    # ==========================================================================
    # REPORTING + LOGGING
    # ==========================================================================
    log_index_name:         str = "scorecard_log"
    log_file_path:          str = field(default_factory=lambda: _resolve_path("logs/scorecard_log.txt"))

    def __post_init__(self):
        """Validate configuration parameters."""
        assert self.training_length >= 2, (
            f"Invalid training_length: {self.training_length}. "
            "Must be at least 2 to include 1+ historical notes."
        )


@dataclass
class ScoreCardState:
    # ==========================================================================
    # Configuration
    # ==========================================================================
    config:                 ScoreCardConfig

    # ==========================================================================
    # RAW + ENRICHED DATAFRAMES (generated during pipeline stages)
    # ==========================================================================
    raw_df:                 Optional[pd.DataFrame] = None
    details_df:             Optional[pd.DataFrame] = None
    enriched_df:            Optional[pd.DataFrame] = None
    sid_df:                 Optional[pd.DataFrame] = None
    predicted_sids:         Optional[pd.DataFrame] = None
    complete_dataset:       Optional[pd.DataFrame] = None
    complete_df:            Optional[pd.DataFrame] = None
    predictions_df:         Optional[pd.DataFrame] = None
    final_df:               Optional[pd.DataFrame] = None

    # ==========================================================================
    # TRAINED MODELS + RESULT TRACKING (Single-horizon - kept for backward compat)
    # ==========================================================================
    models:                 dict[str, dict[str, Any]] = field(default_factory=dict)
    best_model:             Optional[dict[str, Any]] = None
    best_model_key:         Optional[str] = None
    model_grid_df:          Optional[pd.DataFrame] = None
    prepared_datasets:      Optional[dict[str, dict[str, Any]]] = None

    # ==========================================================================
    # MULTI-HORIZON MODEL STORAGE
    # ==========================================================================
    models_by_horizon:          dict[int, dict[str, dict]] = field(default_factory=dict)
    best_model_by_horizon:      dict[int, dict] = field(default_factory=dict)
    best_model_key_by_horizon:  dict[int, str] = field(default_factory=dict)
    predictions_df_by_horizon:  dict[int, pd.DataFrame] = field(default_factory=dict)

    # ==========================================================================
    # LOADED MODEL MATRIX CONFIGS
    # ==========================================================================
    feature_matrix:         Optional[dict[str, dict[str, list[str]]]] = None
    sampling_matrix:        Optional[dict[str, dict[str, Any]]] = None
    vectorization_matrix:   Optional[dict[str, dict[str, str]]] = None
    model_weights:          Optional[list[dict[int, float]]] = None
    text_field_config:      Optional[dict[str, list[str]]] = None
    numeric_fields:         Optional[list[str]] = None
    model_configs:          Optional[list[dict[int, float]]] = None
    vectorizer_params:      Optional[dict[str, Any]] = None

    # ==========================================================================
    # MODEL PIPELINE COMPONENTS
    # ==========================================================================
    vectorizer:             Optional[Any] = None
    X_matrix:               Optional[Any] = None
    y_vector:               Optional[Any] = None
    tokenizer:              Optional[Any] = None
    nlp:                    Optional[spacy.language.Language] = None

    # ==========================================================================
    # EMBEDDING + GPT OBJECTS
    # ==========================================================================
    embedding_model:        Optional[SentenceTransformer] = None
    embedding_dim:          Optional[int] = None

    # ==========================================================================
    # CONNECTION OBJECTS (set by ConnectionManager)
    # ==========================================================================
    sql_connection:         Optional[Any] = None
    es_conn:                Optional[Any] = None
    gpt_client:             Optional[Any] = None

    # ==========================================================================
    # LOADED PROMPTS/QUERIES
    # ==========================================================================
    sql_query:              Optional[str] = None
    gpt_prompt:             Optional[str] = None

    def __post_init__(self) -> None:
        self._load_model_matrices()
        self._initialize_spacy_model()
        self._load_sql_query()
        self._load_prompt_template()

    def _load_model_matrices(self) -> None:
        """
        Loads model feature, sampling, and vectorization matrices from a single JSON config file.
        """
        with open(self.config.model_matrix_json, "r", encoding="utf-8") as f:
            config = json.load(f)

        self.feature_matrix = config.get("feature_matrix", {})
        self.sampling_matrix = config.get("sampling_matrix", {})
        self.vectorization_matrix = config.get("vectorization_matrix", {})
        self.model_weights = config.get("model_weights", None)
        self.vectorizer_params = config.get("vectorizer_params", {})

        # Convert to tuple since JSON can't handle tuples
        if "ngram_range" in self.vectorizer_params:
            self.vectorizer_params["ngram_range"] = tuple(self.vectorizer_params["ngram_range"])

    def _initialize_spacy_model(self) -> None:
        """
        Load the spaCy model, downloading it first if not available.
        NOTE: This is called during __post_init__, so the model is loaded
        immediately when ScoreCardState is instantiated.

        IMPORTANT: GPU must be activated BEFORE loading the model, otherwise
        the model will be loaded on CPU and cannot be moved to GPU later.
        """
        # Activate GPU before loading model (if requested)
        if self.config.require_gpu:
            gpu_activated = spacy.prefer_gpu()
            if gpu_activated:
                print("spaCy GPU acceleration: ENABLED")
            else:
                print("WARNING: spaCy GPU requested but not available. Using CPU.")

        try:
            self.nlp = spacy.load(self.config.spacy_model)
        except OSError:
            print(f"Model '{self.config.spacy_model}' not found. Downloading it now...")
            spacy_download(self.config.spacy_model)
            # Load the model after downloading
            self.nlp = spacy.load(self.config.spacy_model)

    def _load_sql_query(self) -> None:
        """Loads the SQL query from sql_query.txt."""
        with open(self.config.sql_query_file, encoding="utf-8") as f:
            self.sql_query = f.read().strip()

    def _load_prompt_template(self) -> None:
        """
        Loads GPT system prompt from file.
        """
        with open(self.config.gpt_prompt_location, "r", encoding="utf-8") as f:
            self.gpt_prompt = f.read()
