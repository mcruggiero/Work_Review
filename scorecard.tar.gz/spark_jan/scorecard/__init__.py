# ========================================================================
# SCORECARD PACKAGE
# Multi-horizon prediction system for subcontract scorecards
# ========================================================================

"""
ScoreCard ML Pipeline Package

This package provides a complete ML pipeline for predicting subcontract
scorecard outcomes (Green/Yellow/Red) with multi-horizon support.

Main Components:
    - ScoreCardConfig: Configuration dataclass
    - ScoreCardState: State management dataclass
    - ConnectionManager: Database and API connections
    - ScoreCardTextPrep: NLP text preprocessing
    - ScoreCardModeling: ML model training and prediction
    - ScoreCardRag: RAG embeddings and GPT justifications
    - ScoreCardPipeline: Main pipeline orchestrator

Horizons:
    - H1: Predict next card (1 step ahead)
    - H2: Predict card after next (2 steps ahead)

Usage:
    from scorecard import run_pipeline

    state, pipeline, rag = run_pipeline(
        sql_download=True,
        enable_nlp=True,
        build_models=True,
        run_predictions=True,
        build_rag=True,
    )

Or import individual components:
    from scorecard import (
        ScoreCardConfig,
        ScoreCardState,
        ConnectionManager,
        ScoreCardModeling,
        ScoreCardPipeline,
        ScoreCardRag,
        Horizon,
        SUPPORTED_HORIZONS,
    )
"""

from .config import (
    ScoreCardConfig,
    ScoreCardState,
    Horizon,
    SUPPORTED_HORIZONS,
    horizon_offset,
)

from .connections import ConnectionManager

from .text_prep import ScoreCardTextPrep

from .modeling import ScoreCardModeling

from .rag import ScoreCardRag

from .pipeline import ScoreCardPipeline

from .main import run_pipeline, main


__all__ = [
    # Config
    "ScoreCardConfig",
    "ScoreCardState",
    "Horizon",
    "SUPPORTED_HORIZONS",
    "horizon_offset",
    # Connections
    "ConnectionManager",
    # Text Prep
    "ScoreCardTextPrep",
    # Modeling
    "ScoreCardModeling",
    # RAG
    "ScoreCardRag",
    # Pipeline
    "ScoreCardPipeline",
    # Entry points
    "run_pipeline",
    "main",
]

__version__ = "2.0.0"
