# ========================================================================
# SCORECARD RAG MODULE
# Contains: ScoreCardRag for embeddings, vector search, and GPT justifications
# ========================================================================

import os
import json
import time
from typing import Optional
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

import torch
import pandas as pd
import tiktoken
from elasticsearch.helpers import bulk

from .config import ScoreCardConfig, ScoreCardState
from .connections import ConnectionManager


class ScoreCardRag:
    """
    Handles RAG (Retrieval Augmented Generation) operations for ScoreCard.

    Responsibilities:
    - Embedding generation and indexing
    - Similar note retrieval via vector search
    - GPT-based justification generation
    """

    def __init__(
        self,
        config: ScoreCardConfig,
        state: ScoreCardState,
        conn: ConnectionManager
    ) -> None:
        self.config = config
        self.state = state
        self.conn = conn
        self.gpt = conn.gpt_client
        self.gpt_model = "gpt-4o"
        self.max_workers = os.cpu_count() // 4 or 1
        self.responses = []
        self.rag_index = config.rag_index

    def embed_and_index_notes(self) -> None:
        """
        Embeds Scorecard_Note and indexes the entire complete_df into the RAG index.
        """
        es = self.conn.es_client
        df = self.state.complete_df.copy()

        # Use Scorecard_Note as embedding input
        df["text_for_embedding"] = df["Scorecard_Note"].fillna("").astype(str)

        # Date columns
        df["Note_YearMonth"] = df["Note_Year"].astype(int) * 100 + df["Note_Month"].astype(int)
        df["Report_Date"] = pd.to_datetime(
            df["Report_Year"].astype(str) + "-" + df["Report_Month"].astype(str).str.zfill(2) + "-01"
        )

        # Load embedding model and tokenizer
        embedding_model = self.conn.state.embedding_model
        tokenizer = tiktoken.get_encoding(self.config.tokenizer_name)

        # Embed (use GPU if available, otherwise CPU)
        device = "cuda" if torch.cuda.is_available() else "cpu"
        self.conn.report("EMBD", f"Encoding {len(df)} notes for embedding on {device}...")
        embeddings = embedding_model.encode(
            df["text_for_embedding"].tolist(),
            batch_size=self.config.batch_size,
            show_progress_bar=True,
            device=device
        )
        df["embedding"] = embeddings.tolist()

        # Token count + metadata
        df["tokens"] = df["text_for_embedding"].apply(lambda text: tokenizer.encode(text))
        df["token_count"] = df["tokens"].apply(len)
        df["embedding_version"] = self.config.embedding_model_name
        df["gpt_justification"] = ""
        df["created_at"] = datetime.utcnow().isoformat()

        # Use sid_key as the ES _id
        df["_id"] = df["sid_key"].astype(str)

        # Token stats
        token_stats = df["token_count"].describe().to_dict()
        self.conn.report("EMBD", f"Token count stats: {json.dumps(token_stats, indent=2)}")

        # Reset the RAG index
        if es.indices.exists(index=self.rag_index):
            es.indices.delete(index=self.rag_index)
            self.conn.report("ES", f"Deleted existing index '{self.rag_index}'")

        mapping = {
            "mappings": {
                "properties": {
                    "embedding": {
                        "type": "dense_vector",
                        "dims": self.config.embedding_vector_dim,
                        "index": True,
                        "similarity": "cosine"
                    },
                    "tokens": {"type": "integer"},
                    "token_count": {"type": "integer"},
                    "embedding_version": {"type": "keyword"},
                    "gpt_justification": {"type": "text"},
                    "created_at": {"type": "date"},
                    "Note_YearMonth": {"type": "integer"},
                    "SID": {"type": "integer"},
                    "Note_Year": {"type": "integer"},
                    "Note_Month": {"type": "integer"},
                    "Report_Date": {"type": "date"}
                }
            }
        }

        es.indices.create(index=self.rag_index, body=mapping)
        self.conn.report("ES", f"Created index '{self.rag_index}' with vector mapping")

        # Bulk index everything
        actions = []
        for _, row in df.iterrows():
            actions.append({
                "_index": self.rag_index,
                "_id": row["_id"],
                "_source": self.conn.serialize_row_for_es(row)
            })

        success, errors = bulk(es, actions, raise_on_error=False)
        self.conn.report("ES", f"Indexed {success} documents to '{self.rag_index}'")

        if errors:
            self.conn.report("ES", f"{len(errors)} document(s) failed to index.")
            for err in errors[:3]:
                print(json.dumps(err, indent=2))
            raise RuntimeError(f"Errors occurred indexing to '{self.rag_index}'")

    def similar_notes_same_sid(self, anchor_sid_key: str, top_k: int = 5) -> list[dict]:
        """
        Returns top-k similar *past* notes from the same SID, based on sid_key-encoded date.
        Uses cosine similarity over embedded vectors stored in Elasticsearch.
        """
        es = self.conn.es_client

        # Parse sid_key format: SID.YYYY.MM.NNNNNN
        sid_parts = anchor_sid_key.split(".")
        if len(sid_parts) != 4:
            raise ValueError(f"Invalid sid_key format: {anchor_sid_key}")

        anchor_sid = int(sid_parts[0])
        anchor_year = int(sid_parts[1])
        anchor_month = int(sid_parts[2])
        anchor_date_val = anchor_year * 100 + anchor_month

        # Get embedding from Elasticsearch
        query_vector = self._get_embedding(anchor_sid_key)

        # Build RAG similarity + filter query
        query = {
            "size": top_k,
            "query": {
                "script_score": {
                    "query": {
                        "bool": {
                            "must": [
                                {"term": {"SID": anchor_sid}},
                                {
                                    "script": {
                                        "script": {
                                            "source": (
                                                "(doc['Note_Year'].value * 100 + doc['Note_Month'].value) "
                                                "< params.date"
                                            ),
                                            "params": {"date": anchor_date_val}
                                        }
                                    }
                                }
                            ]
                        }
                    },
                    "script": {
                        "source": "cosineSimilarity(params.query_vector, 'embedding') + 1.0",
                        "params": {"query_vector": query_vector}
                    }
                }
            }
        }

        # Execute search
        response = es.search(index=self.rag_index, body=query)
        hits = response.get("hits", {}).get("hits", [])

        if not hits:
            self.conn.report("RAG", f"No prior notes found for SID {anchor_sid} before {anchor_year}-{anchor_month}")

        return [hit["_source"] for hit in hits]

    def get_vendor_trouble_notes(self, anchor_sid_key: str, top_k: int = 5) -> list[dict]:
        """
        Get non-green notes from other SIDs for the same vendor.
        """
        df = self.state.complete_df

        # Parse the anchor sid_key
        sid_parts = anchor_sid_key.split(".")
        if len(sid_parts) != 4:
            raise ValueError(f"Invalid sid_key format: {anchor_sid_key}")
        anchor_sid = int(sid_parts[0])

        # Get vendor ID from anchor row
        anchor_row = df[df["sid_key"] == anchor_sid_key]
        if anchor_row.empty:
            raise ValueError(f"No row found with sid_key={anchor_sid_key}")
        vendor_id = anchor_row.iloc[0]["LM_Vendor_ID"]

        # Filter for other notes from same vendor, different SID, non-green
        filtered = df[
            (df["LM_Vendor_ID"] == vendor_id) &
            (df["SID"] != anchor_sid) &
            (df["Overall"] != "G")
        ].copy()

        # Add a sort key for recency
        filtered["Note_YearMonth"] = (
            filtered["Note_Year"].astype(int) * 100 + filtered["Note_Month"].astype(int)
        )
        filtered.sort_values(by="Note_YearMonth", ascending=False, inplace=True)

        # Group by SID, take top note per SID
        top_notes = (
            filtered.groupby("SID", as_index=False)
            .head(1)
            .sort_values(by="Note_YearMonth", ascending=False)
            .head(top_k)
        )

        return top_notes[["sid_key", "SID", "Scorecard_Note"]].rename(
            columns={"sid_key": "trouble_note_key"}
        ).to_dict(orient="records")

    def retrieve_augmented_history(self, anchor_sid_key: str, top_k: int = 5) -> dict:
        """
        Builds a GPT-friendly payload for a given sid_key.
        """
        df = self.state.complete_df
        anchor_row = df[df["sid_key"] == anchor_sid_key]
        if anchor_row.empty:
            raise ValueError(f"No row found with sid_key={anchor_sid_key}")

        row = anchor_row.iloc[0]

        # Static metadata
        metadata_fields = [
            "SID", "LM_Vendor_ID", "predicted_label", "prob_green", "prob_yellow", "prob_red",
            "all_green", "color_set", "trainable", "predicted_color", "Program_Name"
        ]
        metadata = {k: row[k] for k in metadata_fields if k in row}

        anchor_sid = row["SID"]

        # Explicit note history from sid_key_0, sid_key_1, ...
        explicit_keys = [
            row.get(f"sid_key_{i}")
            for i in range(10)
            if f"sid_key_{i}" in row and pd.notnull(row[f"sid_key_{i}"])
        ]
        explicit_keys_set = set(explicit_keys)

        explicit_notes = (
            df[df["sid_key"].isin(explicit_keys)][["sid_key", "Scorecard_Note"]]
            .rename(columns={"sid_key": "document_key"})
            .to_dict(orient="records")
        )

        # Similar notes via vector search (same SID, earlier date)
        similar_notes = self.similar_notes_same_sid(anchor_sid_key, top_k=top_k)
        similar_cleaned = [
            {
                "document_key": note.get("sid_key", "unknown"),
                "Scorecard_Note": note.get("Scorecard_Note", "")
            }
            for note in similar_notes
            if note.get("sid_key") not in explicit_keys_set
        ]

        sid_key_seen = explicit_keys_set.union({n["document_key"] for n in similar_cleaned})

        # Vendor trouble notes
        vendor_troubles_raw = self.get_vendor_trouble_notes(anchor_sid_key, top_k=top_k)
        vendor_troubles = [
            note for note in vendor_troubles_raw
            if note["trouble_note_key"] not in sid_key_seen
        ]

        # Final payload
        full_history = sorted(explicit_notes + similar_cleaned, key=lambda x: x["document_key"])
        vendor_troubles = sorted(vendor_troubles, key=lambda x: x["trouble_note_key"])

        return {
            "metadata": metadata,
            "note_history": full_history,
            "vendor_troubles": vendor_troubles
        }

    def _format_note_list(self, notes: list[dict], key_name: str = "document_key") -> str:
        """
        Converts a list of notes into a formatted string block for GPT prompt.
        """
        lines = []
        for note in notes:
            key = note.get(key_name, "unknown")
            sid = key.split(".")[0] if "." in key else "?"
            note_id = key.split(".")[-1]
            summary = note.get("Scorecard_Note", "").strip()
            lines.append(f"[{key}] (SID {sid}, Note {note_id})\n{summary}\n")
        return "\n".join(lines)

    def _confidence_from_label(self, label: int, metadata: dict) -> float:
        """
        Retrieves the prediction confidence (as percentage) for a given label.
        """
        confidence_map = {
            0: metadata.get("prob_green", 0),
            1: metadata.get("prob_yellow", 0),
            2: metadata.get("prob_red", 0),
        }
        return confidence_map.get(label, 0.0) * 100

    def generate_justifications(self, anchor_sid_key: str, printer: bool = False) -> None:
        """
        Generates a GPT-based justification for a given sid_key and updates Elasticsearch.
        """
        es = self.conn.es_client
        gpt = self.conn.gpt_client
        prompt_template = self.state.gpt_prompt

        # Retrieve structured history and metadata
        data = self.retrieve_augmented_history(anchor_sid_key)
        metadata = data["metadata"]
        note_history = data["note_history"]
        vendor_troubles = data["vendor_troubles"]

        # Format notes
        recent_notes_block = self._format_note_list(note_history, key_name="document_key")
        vendor_troubles_block = self._format_note_list(vendor_troubles, key_name="trouble_note_key")

        # Compute prediction confidence
        label = metadata.get("predicted_label", -1)
        confidence = self._confidence_from_label(label, metadata)

        prompt = prompt_template.format(
            predicted_color=metadata.get("predicted_color", "Unknown"),
            confidence=confidence,
            SID=metadata.get("SID", "Unknown"),
            LM_Vendor_ID=metadata.get("LM_Vendor_ID", "Unknown"),
            Program_Name=metadata.get("Program_Name", "Unknown"),
            note_history=recent_notes_block,
            vendor_troubles=vendor_troubles_block
        )

        # Call GPT
        response = gpt.chat.completions.create(
            model=self.gpt_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
        )
        justification = response.choices[0].message.content.strip()

        # Save to Elasticsearch
        es.update(
            index=self.rag_index,
            id=anchor_sid_key,
            body={"doc": {"justification": justification}},
        )

        if printer:
            self.conn.report("AI", f"Justification saved for {anchor_sid_key}. Here is the first part:\n {justification}")

    def _get_embedding(self, sid_key: str) -> list[float]:
        """
        Fetches embedding vector directly from Elasticsearch using sid_key as _id.
        """
        es = self.conn.es_client
        try:
            res = es.get(index=self.rag_index, id=sid_key)
            return res["_source"]["embedding"]
        except Exception as e:
            raise RuntimeError(f"Failed to retrieve embedding for sid_key={sid_key}: {e}")

    def run_gpt_justification_pass(
        self,
        limit: Optional[int] = None,
        max_attempts: int = 6,
        backoff: float = 1.5
    ) -> None:
        """
        Runs GPT justification pass across the complete_df using multithreading with retries.
        """
        df = self.state.complete_df.copy()

        if limit is not None:
            df = df.head(limit)

        sid_keys = df["sid_key"].tolist()
        results = [None] * len(sid_keys)

        def process(i: int, sid_key: str):
            for attempt in range(1, max_attempts + 1):
                try:
                    time.sleep(attempt * attempt * backoff)
                    self.generate_justifications(sid_key)
                    self.conn.report("GPT", f"[{i}] {sid_key} succeeded (attempt {attempt})")
                    results[i] = "OK"
                    return
                except Exception as e:
                    self.conn.report("GPT", f"[{i}] {sid_key} failed (attempt {attempt}): {e}")
            results[i] = f"FAILED after {max_attempts} attempts"

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(process, i, sid_key): i
                for i, sid_key in enumerate(sid_keys)
            }
            for future in as_completed(futures):
                _ = future.result()

        success_count = results.count("OK")
        fail_count = len(results) - success_count
        self.conn.report("DONE", f"Justification pass complete: {success_count} succeeded, {fail_count} failed.")
