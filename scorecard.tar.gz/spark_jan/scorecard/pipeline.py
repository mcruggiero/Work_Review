# ========================================================================
# SCORECARD PIPELINE MODULE
# Contains: ScoreCardPipeline - main orchestrator for the ML pipeline
# ========================================================================

import time
import pandas as pd

from .config import ScoreCardConfig, ScoreCardState, SUPPORTED_HORIZONS, Horizon
from .connections import ConnectionManager
from .text_prep import ScoreCardTextPrep
from .modeling import ScoreCardModeling


class ScoreCardPipeline:
    """
    Main pipeline orchestrator for ScoreCard ML workflow.

    Stages:
        1. Download data from SQL or load from Elasticsearch
        2. Text enrichment and window generation
        3. Model training and prediction for multiple horizons
    """

    def __init__(
        self,
        config: ScoreCardConfig,
        state: ScoreCardState,
        conn: ConnectionManager,
        modeler: ScoreCardModeling
    ) -> None:
        self.config = config
        self.state = state
        self.conn = conn
        self.modeler = modeler

    def run(self) -> None:
        """Execute the full pipeline."""
        pipeline_start = time.time()
        self.conn.report("PIPE", "=" * 60)
        self.conn.report("PIPE", "SCORECARD PIPELINE STARTING")
        self.conn.report("PIPE", "=" * 60)
        self.conn.report("PIPE", f"Config: sql_download={self.config.sql_download}, enable_nlp={self.config.enable_nlp}")
        self.conn.report("PIPE", f"Config: build_models={self.config.build_models}, run_predictions={self.config.run_predictions}")
        self.conn.report("PIPE", f"Config: build_rag={self.config.build_rag}")

        self._stage_1_download()
        self._stage_2_text_enrichment()
        self._stage_3_modeling_and_prediction()

        total_time = time.time() - pipeline_start
        self.conn.report("PIPE", "=" * 60)
        self.conn.report("PIPE", f"PIPELINE COMPLETE in {total_time:.1f}s ({total_time/60:.1f} min)")
        self.conn.report("PIPE", "=" * 60)

    def _stage_1_download(self) -> None:
        """Stage 1: Download data from SQL or load from Elasticsearch."""
        self.conn.report("PIPE", "-" * 40)
        self.conn.report("PIPE", "STAGE 1: DATA DOWNLOAD")
        self.conn.report("PIPE", "-" * 40)
        stage_start = time.time()

        if self.config.sql_download:
            self.conn.report("PIPE", "Source: SQL Server")
            self.download_sids()
        else:
            self.conn.report("PIPE", "Source: Elasticsearch (scorecard_details)")
            self.state.details_df = self.conn.load_from_es(
                index_name="scorecard_details",
                id_col="Scorecard_Detail_Note_SID"
            )

        stage_time = time.time() - stage_start
        self.conn.report("PIPE", f"Stage 1 complete in {stage_time:.1f}s - {len(self.state.details_df)} rows loaded")

    def _stage_2_text_enrichment(self) -> None:
        """Stage 2: NLP enrichment and window generation."""
        self.conn.report("PIPE", "-" * 40)
        self.conn.report("PIPE", "STAGE 2: NLP ENRICHMENT & WINDOW GENERATION")
        self.conn.report("PIPE", "-" * 40)
        stage_start = time.time()

        if self.config.enable_nlp:
            self.conn.report("PIPE", "Running fresh NLP enrichment (enable_nlp=True)")
            # NOTE: GPU activation and model loading already handled in ScoreCardState.__post_init__
            # No need to reload here - self.state.nlp is already initialized

            # Pass the reporter for detailed logging
            ScoreCardTextPrep.enrich(self.state, reporter=self.conn.report)
            ScoreCardTextPrep.build_sid_history(self.state, reporter=self.conn.report)

            self.conn.report("PIPE", "Uploading enriched data to Elasticsearch...")
            drop_enriched = ["pre_scrub_text", "verbs", "adjectives", "noun_chunks"]
            drop_sid_df = [col for col in self.state.sid_df.columns if col.startswith("nlp_")]

            self.conn.upload_dataframe_to_es(
                df=self.state.enriched_df.drop(columns=drop_enriched),
                index_name="scorecard_enriched",
                id_col="sid_key"
            )

            self.conn.upload_dataframe_to_es(
                df=self.state.sid_df.drop(columns=drop_sid_df, errors='ignore'),
                index_name="scorecard_sid_history",
            )
        else:
            self.conn.report("PIPE", "Loading pre-computed data from Elasticsearch (enable_nlp=False)")
            self.state.enriched_df = self.conn.load_from_es(
                index_name="scorecard_enriched",
                id_col="sid_key"
            )
            self.state.sid_df = self.conn.load_from_es(index_name="scorecard_sid_history")

        stage_time = time.time() - stage_start
        self.conn.report("PIPE", f"Stage 2 complete in {stage_time:.1f}s")
        self.conn.report("PIPE", f"  -> enriched_df: {len(self.state.enriched_df)} rows")
        self.conn.report("PIPE", f"  -> sid_df: {len(self.state.sid_df)} windows")

    def _stage_3_modeling_and_prediction(self) -> None:
        """
        Stage 3: Model training and prediction for all supported horizons.

        Trains separate models for H1 (next card) and H2 (card after next),
        each with independent evaluation, model selection, and predictions.
        """
        self.conn.report("PIPE", "-" * 40)
        self.conn.report("PIPE", "STAGE 3: MODEL TRAINING & PREDICTION")
        self.conn.report("PIPE", "-" * 40)
        stage_start = time.time()

        if not self.config.build_models:
            self.conn.report("PIPE", "Skipping model training (build_models=False)")
            self.conn.report("PIPE", "Loading pre-computed predictions from Elasticsearch...")
            self.state.predictions_df = self.conn.load_from_es(index_name="scorecard_predictions")
            self.modeler.merge_data()
            return

        modeler = self.modeler
        self.conn.report("PIPE", "Building model configuration grid...")
        modeler.build_model_grid()
        grid_size = len(modeler.state.model_grid_df) if modeler.state.model_grid_df is not None else 0
        self.conn.report("PIPE", f"  -> {grid_size} model configurations in grid")

        self.conn.report("PIPE", f"Training models for {len(SUPPORTED_HORIZONS)} horizons: {[f'H{int(h)}' for h in SUPPORTED_HORIZONS]}")

        # Train and predict for each horizon
        for horizon in SUPPORTED_HORIZONS:
            h_int = int(horizon)
            self.conn.report("PIPE", f"=== Starting Horizon H{h_int} ===")

            # Get model key from config, or run full grid search if not specified
            # NOTE: Model keys specify the exact configuration to use:
            #   "feature_set | sampling_strategy | vectorizer | class_weights"
            # H1 uses legacy format (no prefix), H2+ use "H{n} | ..." prefix
            if horizon == Horizon.H1:
                model_key = self.config.default_model_key_h1
            else:
                # H2+ model keys need horizon prefix for load_best_model_by_key() to parse correctly
                base_key = self.config.default_model_key_h2
                model_key = f"H{h_int} | {base_key}" if base_key else None

            try:
                if model_key:
                    # Use predetermined model configuration
                    df_with_predictions = modeler.load_best_model_by_key(
                        model_key,
                        horizon=horizon,
                        generate_predictions=self.config.run_predictions
                    )
                else:
                    # No default key specified - run full grid search to find best model
                    self.conn.report("PIPE", f"[H{h_int}] No default model key - running grid search")
                    modeler.find_best_model(horizon=horizon)
                    if self.config.run_predictions:
                        df_with_predictions = modeler.predict_with_best_model(
                            self.state.sid_df, horizon=horizon
                        )

                best_key = self.state.best_model_key_by_horizon.get(h_int)
                self.conn.report("ML", f"[H{h_int}] Best model: {best_key}")

            except Exception as e:
                self.conn.report("ML", f"[H{h_int}] Model training failed: {str(e)}")
                continue

        # Collect model summaries from all horizons
        all_model_summaries = []
        for h_int, models in self.state.models_by_horizon.items():
            for k, v in models.items():
                all_model_summaries.append({
                    "horizon": h_int,
                    "model_id": k,
                    "false_negatives": v.get("total_false_negatives"),
                    "accuracy": v.get("accuracy"),
                    "y_counts": v.get("y_counts"),
                    "y_pred_counts": v.get("y_pred_counts"),
                    "error": v.get("error")
                })

        if all_model_summaries:
            model_summary = pd.DataFrame(all_model_summaries)
            self.conn.upload_dataframe_to_es(model_summary.fillna(""), index_name="scorecard_model_summary")

        # Upload H1 predictions
        if self.config.run_predictions and self.state.predictions_df is not None:
            self.conn.upload_dataframe_to_es(
                df=self.state.predictions_df,
                index_name="scorecard_predictions",
            )
            self.conn.report("ML", "H1 predictions uploaded to 'scorecard_predictions'")

            # Also upload H2 predictions to separate index
            h2_df = self.state.predictions_df_by_horizon.get(2)
            if h2_df is not None:
                self.conn.upload_dataframe_to_es(
                    df=h2_df,
                    index_name="scorecard_predictions_h2",
                )
                self.conn.report("ML", "H2 predictions uploaded to 'scorecard_predictions_h2'")

        # Merge all horizon predictions into complete_df
        self.conn.report("PIPE", "Merging predictions from all horizons...")
        self.modeler.merge_data()

        stage_time = time.time() - stage_start
        self.conn.report("PIPE", f"Stage 3 complete in {stage_time:.1f}s ({stage_time/60:.1f} min)")

        # Summary of results
        if self.state.complete_df is not None:
            self.conn.report("PIPE", f"  -> complete_df: {len(self.state.complete_df)} rows")
            if "predicted_color" in self.state.complete_df.columns:
                pred_dist = self.state.complete_df["predicted_color"].value_counts().to_dict()
                self.conn.report("PIPE", f"  -> H1 predictions: {pred_dist}")
            if "predicted_color_h2" in self.state.complete_df.columns:
                pred_dist_h2 = self.state.complete_df["predicted_color_h2"].value_counts().to_dict()
                self.conn.report("PIPE", f"  -> H2 predictions: {pred_dist_h2}")

    def download_sids(self) -> None:
        """Download data from SQL Server."""
        query = self.state.sql_query
        conn = self.state.sql_connection
        df = pd.read_sql(query, conn)

        self.state.details_df = df
        self.conn.report("SQL", f"{len(df)} rows downloaded and stored in state.details_df.")
        self.conn.upload_dataframe_to_es(df, index_name="scorecard_details")
