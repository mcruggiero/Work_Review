# ========================================================================
# SCORECARD PIPELINE MODULE
# Contains: ScoreCardPipeline - main orchestrator for the ML pipeline
# ========================================================================

import pandas as pd

from .config import ScoreCardConfig, ScoreCardState, SUPPORTED_HORIZONS, Horizon
from .connections import ConnectionManager
from .text_prep import ScoreCardTextPrep
from .modeling import ScoreCardModeling


class ScoreCardPipeline:
    """
    Main pipeline orchestrator for ScoreCard ML workflow.

    Stages:
        1. Download data from SQL or load from Elasticsearch
        2. Text enrichment and window generation
        3. Model training and prediction for multiple horizons
    """

    def __init__(
        self,
        config: ScoreCardConfig,
        state: ScoreCardState,
        conn: ConnectionManager,
        modeler: ScoreCardModeling
    ) -> None:
        self.config = config
        self.state = state
        self.conn = conn
        self.modeler = modeler

    def run(self) -> None:
        """Execute the full pipeline."""
        self._stage_1_download()
        self._stage_2_text_enrichment()
        self._stage_3_modeling_and_prediction()

    def _stage_1_download(self) -> None:
        """Stage 1: Download data from SQL or load from Elasticsearch."""
        if self.config.sql_download:
            self.download_sids()
        else:
            self.state.details_df = self.conn.load_from_es(
                index_name="scorecard_details",
                id_col="Scorecard_Detail_Note_SID"
            )

        self.conn.report("PIPE", "Completed all Downloads from SQL or ES")

    def _stage_2_text_enrichment(self) -> None:
        """Stage 2: NLP enrichment and window generation."""
        if self.config.enable_nlp:
            # NOTE: GPU activation and model loading already handled in ScoreCardState.__post_init__
            # No need to reload here - self.state.nlp is already initialized

            ScoreCardTextPrep.enrich(self.state)
            ScoreCardTextPrep.build_sid_history(self.state)

            drop_enriched = ["pre_scrub_text", "verbs", "adjectives", "noun_chunks"]
            drop_sid_df = [col for col in self.state.sid_df.columns if col.startswith("nlp_")]

            self.conn.upload_dataframe_to_es(
                df=self.state.enriched_df.drop(columns=drop_enriched),
                index_name="scorecard_enriched",
                id_col="sid_key"
            )

            self.conn.upload_dataframe_to_es(
                df=self.state.sid_df.drop(columns=drop_sid_df, errors='ignore'),
                index_name="scorecard_sid_history",
            )
        else:
            self.state.enriched_df = self.conn.load_from_es(
                index_name="scorecard_enriched",
                id_col="sid_key"
            )
            self.state.sid_df = self.conn.load_from_es(index_name="scorecard_sid_history")

        self.conn.report("PIPE", "Completed all Text Prep Steps")

    def _stage_3_modeling_and_prediction(self) -> None:
        """
        Stage 3: Model training and prediction for all supported horizons.

        Trains separate models for H1 (next card) and H2 (card after next),
        each with independent evaluation, model selection, and predictions.
        """
        if not self.config.build_models:
            self.state.predictions_df = self.conn.load_from_es(index_name="scorecard_predictions")
            self.modeler.merge_data()
            return

        modeler = self.modeler
        modeler.build_model_grid()

        self.conn.report("PIPE", f"Training models for {len(SUPPORTED_HORIZONS)} horizons: {[f'H{int(h)}' for h in SUPPORTED_HORIZONS]}")

        # Train and predict for each horizon
        for horizon in SUPPORTED_HORIZONS:
            h_int = int(horizon)
            self.conn.report("PIPE", f"=== Starting Horizon H{h_int} ===")

            # Get model key from config, or run full grid search if not specified
            # NOTE: Model keys specify the exact configuration to use:
            #   "feature_set | sampling_strategy | vectorizer | class_weights"
            # H1 uses legacy format (no prefix), H2+ use "H{n} | ..." prefix
            if horizon == Horizon.H1:
                model_key = self.config.default_model_key_h1
            else:
                # H2+ model keys need horizon prefix for load_best_model_by_key() to parse correctly
                base_key = self.config.default_model_key_h2
                model_key = f"H{h_int} | {base_key}" if base_key else None

            try:
                if model_key:
                    # Use predetermined model configuration
                    df_with_predictions = modeler.load_best_model_by_key(
                        model_key,
                        horizon=horizon,
                        generate_predictions=self.config.run_predictions
                    )
                else:
                    # No default key specified - run full grid search to find best model
                    self.conn.report("PIPE", f"[H{h_int}] No default model key - running grid search")
                    modeler.find_best_model(horizon=horizon)
                    if self.config.run_predictions:
                        df_with_predictions = modeler.predict_with_best_model(
                            self.state.sid_df, horizon=horizon
                        )

                best_key = self.state.best_model_key_by_horizon.get(h_int)
                self.conn.report("ML", f"[H{h_int}] Best model: {best_key}")

            except Exception as e:
                self.conn.report("ML", f"[H{h_int}] Model training failed: {str(e)}")
                continue

        # Collect model summaries from all horizons
        all_model_summaries = []
        for h_int, models in self.state.models_by_horizon.items():
            for k, v in models.items():
                all_model_summaries.append({
                    "horizon": h_int,
                    "model_id": k,
                    "false_negatives": v.get("total_false_negatives"),
                    "accuracy": v.get("accuracy"),
                    "y_counts": v.get("y_counts"),
                    "y_pred_counts": v.get("y_pred_counts"),
                    "error": v.get("error")
                })

        if all_model_summaries:
            model_summary = pd.DataFrame(all_model_summaries)
            self.conn.upload_dataframe_to_es(model_summary.fillna(""), index_name="scorecard_model_summary")

        # Upload H1 predictions
        if self.config.run_predictions and self.state.predictions_df is not None:
            self.conn.upload_dataframe_to_es(
                df=self.state.predictions_df,
                index_name="scorecard_predictions",
            )
            self.conn.report("ML", "H1 predictions uploaded to 'scorecard_predictions'")

            # Also upload H2 predictions to separate index
            h2_df = self.state.predictions_df_by_horizon.get(2)
            if h2_df is not None:
                self.conn.upload_dataframe_to_es(
                    df=h2_df,
                    index_name="scorecard_predictions_h2",
                )
                self.conn.report("ML", "H2 predictions uploaded to 'scorecard_predictions_h2'")

        # Merge all horizon predictions into complete_df
        self.modeler.merge_data()

    def download_sids(self) -> None:
        """Download data from SQL Server."""
        query = self.state.sql_query
        conn = self.state.sql_connection
        df = pd.read_sql(query, conn)

        self.state.details_df = df
        self.conn.report("SQL", f"{len(df)} rows downloaded and stored in state.details_df.")
        self.conn.upload_dataframe_to_es(df, index_name="scorecard_details")
