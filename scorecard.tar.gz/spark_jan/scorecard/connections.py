# ========================================================================
# SCORECARD CONNECTIONS MODULE
# Contains: ConnectionManager for SQL, Elasticsearch, GPT, Embeddings
# ========================================================================

import os
import json
from typing import Any, Optional
from datetime import datetime

import numpy as np
import pandas as pd
import pyodbc
import torch
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk, scan
from openai import OpenAI
from sentence_transformers import SentenceTransformer

from .config import ScoreCardConfig, ScoreCardState


class ConnectionManager:
    """
    Manages connections to SQL Server, Elasticsearch, GPT API, and embedding models.
    Also provides logging/reporting and DataFrame serialization utilities.
    """

    def __init__(self, config: ScoreCardConfig, state: ScoreCardState) -> None:
        self.config = config
        self.state = state
        self.log_file_path = config.log_file_path
        self.log_index_name = config.log_index_name

        # Core client handles
        self.sql_conn = None
        self.es_client = None
        self.gpt_client = None

        # Connect in proper order
        self._connect_elasticsearch()  # Needed before using self.report
        self._connect_sql()
        self._connect_gpt()
        self._load_embedding_model()

    def _connect_sql(self) -> None:
        conn_str = (
            f"DRIVER={{{self.config.sql_driver_path}}};"
            f"SERVER={self.config.sql_server};"
            f"DATABASE={self.config.sql_database};"
            f"UID={self.config.sql_uid};"
            f"PWD={self.config.sql_pwd}"
        )
        self.sql_conn = pyodbc.connect(conn_str)
        if self.sql_conn is None:
            raise ConnectionError("SQL connection returned None")
        self.state.sql_connection = self.sql_conn
        self.report("CONN", "SQL connection established.")

    def _connect_elasticsearch(self) -> None:
        self.es_client = Elasticsearch(self.config.es_host)
        if not self.es_client.ping():
            raise ConnectionError("Elasticsearch ping failed")
        self.state.es_conn = self.es_client
        self.report("CONN", "Elasticsearch connection established.")

    def _connect_gpt(self) -> None:
        self.gpt_client = OpenAI(
            base_url=self.config.gpt_base_url,
            api_key=os.getenv("OPENAI_API_KEY")
        )
        if self.gpt_client is None:
            raise ConnectionError("GPT client initialization failed")
        self.state.gpt_client = self.gpt_client
        self.report("CONN", "GPT client initialized.")

    def _load_embedding_model(self) -> None:
        """
        Loads the sentence embedding model and stores it in state.
        Uses GPU if available, otherwise falls back to CPU.
        """
        device = "cuda" if torch.cuda.is_available() else "cpu"
        self.report("EMBD", f"Loading embedding model '{self.config.embedding_model_name}' to {device}")

        model = SentenceTransformer(self.config.embedding_model_name)
        model = model.to(device)

        self.state.embedding_model = model
        self.state.embedding_dim = model.get_sentence_embedding_dimension()
        self.report("EMBD", f"Embedding model loaded with dim {self.state.embedding_dim}")

    def report(self, tag: str, message: str, meta: dict = None) -> None:
        """Log a message to console, file, and Elasticsearch."""
        timestamp = datetime.utcnow().isoformat()
        full_message = f"[{tag.upper()}] \t{message}"
        print(full_message)

        # Log to file
        os.makedirs(os.path.dirname(self.log_file_path), exist_ok=True)
        with open(self.log_file_path, "a") as f:
            f.write(f"{timestamp} {full_message}\n")

        # Log to Elasticsearch
        if self.es_client:
            self.es_client.index(index=self.log_index_name, document={
                "timestamp": timestamp,
                "tag": tag.upper(),
                "message": message,
                "meta": meta or {}
            })

    @staticmethod
    def is_scalar(val: Any) -> bool:
        return isinstance(val, (
            str, int, float, bool, type(None),
            pd.Timestamp, datetime, np.integer, np.floating
        ))

    @staticmethod
    def is_valid_list(val: Any) -> bool:
        if isinstance(val, (list, tuple, np.ndarray)):
            return all(ConnectionManager.is_scalar(v) or pd.isna(v) for v in val)
        return False

    @staticmethod
    def clean(val: Any) -> Any:
        """
        Converts a Python object into a JSON-safe primitive for Elasticsearch.
        """
        if isinstance(val, (pd.Timestamp, datetime)):
            return val.isoformat()

        if isinstance(val, (np.integer, np.floating)):
            return val.item()

        if ConnectionManager.is_scalar(val) and pd.isna(val):
            return None

        if isinstance(val, np.ndarray):
            return [ConnectionManager.clean(v) for v in val.tolist()]

        if isinstance(val, (list, tuple)):
            return [ConnectionManager.clean(v) for v in val]

        if ConnectionManager.is_scalar(val):
            return val

        raise TypeError(f"Unsupported type for serialization: {type(val)} | Value: {repr(val)}")

    def serialize_row_for_es(self, row: pd.Series, drop_keys: list[str] = None) -> dict:
        """Serialize a DataFrame row to an Elasticsearch-compatible dict."""
        drop_keys = set(drop_keys or [])
        drop_keys.add("_id")  # Always drop ES-reserved field

        result = {}
        for k, v in row.items():
            if k in drop_keys:
                continue
            if self.is_scalar(v) or self.is_valid_list(v):
                result[k] = self.clean(v)

        return result

    def upload_dataframe_to_es(
        self,
        df: pd.DataFrame,
        index_name: str,
        id_col: Optional[str] = None
    ) -> None:
        """
        Uploads a DataFrame to Elasticsearch using bulk indexing.
        Deletes and recreates the index before uploading.
        """
        # Ensure an ID column is available
        if id_col is not None:
            if id_col not in df.columns:
                raise ValueError(f"id_col '{id_col}' not found in DataFrame columns.")
            df = df.copy()
            df["_id"] = df[id_col].astype(str)
        else:
            df = df.copy()
            df["_id"] = df.index.astype(str)

        # Check for embedding column - handle separately if present
        if "embedding" in df.columns:
            self._upload_embedded_dataframe(df, index_name)
            return

        # Delete + recreate index
        if self.es_client.indices.exists(index=index_name):
            self.es_client.indices.delete(index=index_name)
        self.es_client.indices.create(index=index_name)

        # Build bulk actions
        actions = []
        for _, row in df.iterrows():
            actions.append({
                "_index": index_name,
                "_id": row["_id"],
                "_source": self.serialize_row_for_es(row)
            })

        # Upload to Elasticsearch
        success, errors = bulk(
            self.es_client,
            actions,
            stats_only=False,
            raise_on_error=False,
            raise_on_exception=False
        )

        if errors:
            self.report("ES", f"{len(errors)} document(s) failed to index.")
            for error in errors[:5]:
                print("-" * 60)
                print(json.dumps(error, indent=2))
            raise RuntimeError(f"Bulk upload to '{index_name}' failed for {len(errors)} document(s).")

        self.report("ES", f"Indexed {success} documents to '{index_name}' with 0 errors.")

    def _upload_embedded_dataframe(self, df: pd.DataFrame, index_name: str) -> None:
        """
        Upload a DataFrame that contains embedding vectors.
        Creates appropriate dense_vector mapping.
        """
        # This method handles the special case of embedding uploads
        # Implementation would go here based on your specific needs
        self.report("ES", f"Embedded DataFrame upload to '{index_name}' - delegating to RAG module")

    def load_from_es(self, index_name: str, id_col: str = "sid") -> pd.DataFrame:
        """Load all documents from an Elasticsearch index into a DataFrame."""
        self.report("ES", f"Loading data from index '{index_name}'...")

        query = {
            "query": {"match_all": {}},
            "_source": True
        }

        scroll = scan(
            client=self.es_client,
            index=index_name,
            query=query,
            preserve_order=True,
            scroll="2m"
        )

        rows = []
        for doc in scroll:
            row = doc["_source"]
            row[id_col] = doc["_id"]
            rows.append(row)

        df = pd.DataFrame(rows)
        self.report("ES", f"Loaded {len(df)} rows from '{index_name}'")
        return df
